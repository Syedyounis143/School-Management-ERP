CREATE TABLE `book_chapters` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`chapterNumber` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`startPage` int,
	`endPage` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `book_chapters_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `book_topics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`chapterId` int NOT NULL,
	`topicNumber` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`keywords` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `book_topics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `question_paper_questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`paperId` int NOT NULL,
	`questionId` int NOT NULL,
	`sectionNumber` int DEFAULT 1,
	`questionOrder` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `question_paper_questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `question_paper_templates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`classLevel` varchar(50) NOT NULL,
	`subject` varchar(100) NOT NULL,
	`totalMarks` decimal(5,2) NOT NULL,
	`totalTime` int,
	`configuration` json,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `question_paper_templates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `question_papers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`classLevel` varchar(50) NOT NULL,
	`subject` varchar(100) NOT NULL,
	`totalMarks` decimal(5,2) NOT NULL,
	`totalTime` int,
	`templateName` varchar(255),
	`isTemplate` boolean DEFAULT false,
	`createdBy` int NOT NULL,
	`status` enum('draft','published','archived') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `question_papers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int,
	`chapterId` int,
	`topicId` int,
	`questionType` enum('mcq','short_answer','long_answer','fill_blank','true_false') NOT NULL,
	`questionText` text NOT NULL,
	`difficulty` enum('easy','medium','hard') NOT NULL DEFAULT 'medium',
	`marks` decimal(5,2) DEFAULT '1',
	`options` json,
	`correctAnswer` text,
	`explanation` text,
	`imageUrl` varchar(500),
	`createdBy` int NOT NULL,
	`status` enum('active','archived','draft') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `scert_books` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`author` varchar(255) NOT NULL,
	`publisher` varchar(255),
	`isbn` varchar(20),
	`classLevel` varchar(50) NOT NULL,
	`subject` varchar(100) NOT NULL,
	`description` text,
	`fileUrl` varchar(500) NOT NULL,
	`filePath` varchar(500) NOT NULL,
	`fileSize` int,
	`totalPages` int,
	`uploadedBy` int NOT NULL,
	`status` enum('active','archived','draft') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `scert_books_id` PRIMARY KEY(`id`),
	CONSTRAINT `scert_books_isbn_unique` UNIQUE(`isbn`)
);
--> statement-breakpoint
ALTER TABLE `book_chapters` ADD CONSTRAINT `book_chapters_bookId_scert_books_id_fk` FOREIGN KEY (`bookId`) REFERENCES `scert_books`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `book_topics` ADD CONSTRAINT `book_topics_chapterId_book_chapters_id_fk` FOREIGN KEY (`chapterId`) REFERENCES `book_chapters`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `question_paper_questions` ADD CONSTRAINT `question_paper_questions_paperId_question_papers_id_fk` FOREIGN KEY (`paperId`) REFERENCES `question_papers`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `question_paper_questions` ADD CONSTRAINT `question_paper_questions_questionId_questions_id_fk` FOREIGN KEY (`questionId`) REFERENCES `questions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `question_paper_templates` ADD CONSTRAINT `question_paper_templates_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `question_papers` ADD CONSTRAINT `question_papers_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `questions` ADD CONSTRAINT `questions_bookId_scert_books_id_fk` FOREIGN KEY (`bookId`) REFERENCES `scert_books`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `questions` ADD CONSTRAINT `questions_chapterId_book_chapters_id_fk` FOREIGN KEY (`chapterId`) REFERENCES `book_chapters`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `questions` ADD CONSTRAINT `questions_topicId_book_topics_id_fk` FOREIGN KEY (`topicId`) REFERENCES `book_topics`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `questions` ADD CONSTRAINT `questions_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `scert_books` ADD CONSTRAINT `scert_books_uploadedBy_users_id_fk` FOREIGN KEY (`uploadedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;