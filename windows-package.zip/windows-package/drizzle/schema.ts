import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  date,
  boolean,
  tinyint,
  json,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["admin", "teacher", "student", "parent"]).default("student").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Students table
 */
export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").references(() => users.id),
  rollNumber: varchar("rollNumber", { length: 50 }).notNull().unique(),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  dateOfBirth: date("dateOfBirth"),
  gender: mysqlEnum("gender", ["male", "female", "other"]),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  address: text("address"),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 100 }),
  zipCode: varchar("zipCode", { length: 20 }),
  fatherName: varchar("fatherName", { length: 100 }),
  fatherPhone: varchar("fatherPhone", { length: 20 }),
  motherName: varchar("motherName", { length: 100 }),
  motherPhone: varchar("motherPhone", { length: 20 }),
  emergencyContact: varchar("emergencyContact", { length: 100 }),
  emergencyPhone: varchar("emergencyPhone", { length: 20 }),
  enrollmentDate: date("enrollmentDate").notNull(),
  status: mysqlEnum("status", ["active", "inactive", "graduated", "transferred"]).default("active").notNull(),
  classId: int("classId").references(() => classes.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;

/**
 * Teachers table
 */
export const teachers = mysqlTable("teachers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").references(() => users.id),
  employeeId: varchar("employeeId", { length: 50 }).notNull().unique(),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  dateOfBirth: date("dateOfBirth"),
  gender: mysqlEnum("gender", ["male", "female", "other"]),
  address: text("address"),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 100 }),
  zipCode: varchar("zipCode", { length: 20 }),
  qualification: varchar("qualification", { length: 200 }),
  experience: int("experience"), // in years
  joiningDate: date("joiningDate").notNull(),
  status: mysqlEnum("status", ["active", "inactive", "on_leave"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Teacher = typeof teachers.$inferSelect;
export type InsertTeacher = typeof teachers.$inferInsert;

/**
 * Classes table
 */
export const classes = mysqlTable("classes", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  section: varchar("section", { length: 50 }).notNull(),
  capacity: int("capacity").notNull(),
  classTeacherId: int("classTeacherId").references(() => teachers.id),
  academicYear: varchar("academicYear", { length: 20 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Class = typeof classes.$inferSelect;
export type InsertClass = typeof classes.$inferInsert;

/**
 * Subjects table
 */
export const subjects = mysqlTable("subjects", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = typeof subjects.$inferInsert;

/**
 * Teacher-Subject assignments
 */
export const teacherSubjects = mysqlTable("teacher_subjects", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").references(() => teachers.id).notNull(),
  subjectId: int("subjectId").references(() => subjects.id).notNull(),
  classId: int("classId").references(() => classes.id).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TeacherSubject = typeof teacherSubjects.$inferSelect;
export type InsertTeacherSubject = typeof teacherSubjects.$inferInsert;

/**
 * Attendance table
 */
export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").references(() => students.id).notNull(),
  classId: int("classId").references(() => classes.id).notNull(),
  date: date("date").notNull(),
  status: mysqlEnum("status", ["present", "absent", "late", "leave"]).notNull(),
  remarks: text("remarks"),
  markedBy: int("markedBy").references(() => teachers.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = typeof attendance.$inferInsert;

/**
 * Exams table
 */
export const exams = mysqlTable("exams", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  startDate: date("startDate").notNull(),
  endDate: date("endDate").notNull(),
  academicYear: varchar("academicYear", { length: 20 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Exam = typeof exams.$inferSelect;
export type InsertExam = typeof exams.$inferInsert;

/**
 * Marks/Grades table
 */
export const marks = mysqlTable("marks", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").references(() => students.id).notNull(),
  examId: int("examId").references(() => exams.id).notNull(),
  subjectId: int("subjectId").references(() => subjects.id).notNull(),
  marksObtained: decimal("marksObtained", { precision: 5, scale: 2 }).notNull(),
  totalMarks: decimal("totalMarks", { precision: 5, scale: 2 }).notNull(),
  grade: varchar("grade", { length: 5 }),
  remarks: text("remarks"),
  enteredBy: int("enteredBy").references(() => teachers.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Mark = typeof marks.$inferSelect;
export type InsertMark = typeof marks.$inferInsert;

/**
 * Fee Structure table
 */
export const feeStructures = mysqlTable("fee_structures", {
  id: int("id").autoincrement().primaryKey(),
  classId: int("classId").references(() => classes.id).notNull(),
  feeType: varchar("feeType", { length: 100 }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  dueDate: date("dueDate").notNull(),
  academicYear: varchar("academicYear", { length: 20 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FeeStructure = typeof feeStructures.$inferSelect;
export type InsertFeeStructure = typeof feeStructures.$inferInsert;

/**
 * Fee Payments table
 */
export const feePayments = mysqlTable("fee_payments", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").references(() => students.id).notNull(),
  feeStructureId: int("feeStructureId").references(() => feeStructures.id).notNull(),
  amountPaid: decimal("amountPaid", { precision: 10, scale: 2 }).notNull(),
  paymentDate: date("paymentDate").notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "check", "online", "bank_transfer"]).notNull(),
  receiptNumber: varchar("receiptNumber", { length: 100 }).unique(),
  status: mysqlEnum("status", ["completed", "pending", "failed"]).default("completed").notNull(),
  remarks: text("remarks"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FeePayment = typeof feePayments.$inferSelect;
export type InsertFeePayment = typeof feePayments.$inferInsert;

/**
 * Library Books table
 */
export const books = mysqlTable("books", {
  id: int("id").autoincrement().primaryKey(),
  isbn: varchar("isbn", { length: 50 }).unique(),
  title: varchar("title", { length: 200 }).notNull(),
  author: varchar("author", { length: 100 }).notNull(),
  publisher: varchar("publisher", { length: 100 }),
  publicationYear: int("publicationYear"),
  category: varchar("category", { length: 100 }),
  quantity: int("quantity").notNull(),
  availableQuantity: int("availableQuantity").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Book = typeof books.$inferSelect;
export type InsertBook = typeof books.$inferInsert;

/**
 * Book Issue/Return tracking
 */
export const bookIssues = mysqlTable("book_issues", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").references(() => books.id).notNull(),
  studentId: int("studentId").references(() => students.id).notNull(),
  issueDate: date("issueDate").notNull(),
  dueDate: date("dueDate").notNull(),
  returnDate: date("returnDate"),
  fineAmount: decimal("fineAmount", { precision: 10, scale: 2 }).default("0"),
  status: mysqlEnum("status", ["issued", "returned", "overdue"]).default("issued").notNull(),
  remarks: text("remarks"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BookIssue = typeof bookIssues.$inferSelect;
export type InsertBookIssue = typeof bookIssues.$inferInsert;

/**
 * Timetable table
 */
export const timetables = mysqlTable("timetables", {
  id: int("id").autoincrement().primaryKey(),
  classId: int("classId").references(() => classes.id).notNull(),
  dayOfWeek: mysqlEnum("dayOfWeek", ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]).notNull(),
  periodNumber: int("periodNumber").notNull(),
  startTime: varchar("startTime", { length: 10 }).notNull(),
  endTime: varchar("endTime", { length: 10 }).notNull(),
  subjectId: int("subjectId").references(() => subjects.id).notNull(),
  teacherId: int("teacherId").references(() => teachers.id).notNull(),
  room: varchar("room", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Timetable = typeof timetables.$inferSelect;
export type InsertTimetable = typeof timetables.$inferInsert;

/**
 * Announcements table
 */
export const announcements = mysqlTable("announcements", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  content: text("content").notNull(),
  targetAudience: mysqlEnum("targetAudience", ["all", "students", "teachers", "parents", "staff"]).default("all").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  publishedDate: timestamp("publishedDate").defaultNow().notNull(),
  expiryDate: timestamp("expiryDate"),
  createdBy: int("createdBy").references(() => users.id).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Announcement = typeof announcements.$inferSelect;
export type InsertAnnouncement = typeof announcements.$inferInsert;

/**
 * Events table
 */
export const events = mysqlTable("events", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  eventDate: date("eventDate").notNull(),
  startTime: varchar("startTime", { length: 10 }),
  endTime: varchar("endTime", { length: 10 }),
  location: varchar("location", { length: 200 }),
  organizer: varchar("organizer", { length: 100 }),
  category: varchar("category", { length: 100 }),
  createdBy: int("createdBy").references(() => users.id).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Event = typeof events.$inferSelect;
export type InsertEvent = typeof events.$inferInsert;


/**
 * SCERT Telangana Books table
 */
export const scertBooks = mysqlTable("scert_books", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  author: varchar("author", { length: 255 }).notNull(),
  publisher: varchar("publisher", { length: 255 }),
  isbn: varchar("isbn", { length: 20 }).unique(),
  classLevel: varchar("classLevel", { length: 50 }).notNull(),
  subject: varchar("subject", { length: 100 }).notNull(),
  description: text("description"),
  fileUrl: varchar("fileUrl", { length: 500 }).notNull(),
  filePath: varchar("filePath", { length: 500 }).notNull(),
  fileSize: int("fileSize"),
  totalPages: int("totalPages"),
  uploadedBy: int("uploadedBy").references(() => users.id).notNull(),
  status: mysqlEnum("status", ["active", "archived", "draft"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ScertBook = typeof scertBooks.$inferSelect;
export type InsertScertBook = typeof scertBooks.$inferInsert;

/**
 * Book Chapters table
 */
export const bookChapters = mysqlTable("book_chapters", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").references(() => scertBooks.id).notNull(),
  chapterNumber: int("chapterNumber").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  startPage: int("startPage"),
  endPage: int("endPage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type BookChapter = typeof bookChapters.$inferSelect;
export type InsertBookChapter = typeof bookChapters.$inferInsert;

/**
 * Book Topics/Lessons table
 */
export const bookTopics = mysqlTable("book_topics", {
  id: int("id").autoincrement().primaryKey(),
  chapterId: int("chapterId").references(() => bookChapters.id).notNull(),
  topicNumber: int("topicNumber").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  keywords: varchar("keywords", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type BookTopic = typeof bookTopics.$inferSelect;
export type InsertBookTopic = typeof bookTopics.$inferInsert;

/**
 * Questions table
 */
export const questions = mysqlTable("questions", {
  id: int("id").autoincrement().primaryKey(),
  bookId: int("bookId").references(() => scertBooks.id),
  chapterId: int("chapterId").references(() => bookChapters.id),
  topicId: int("topicId").references(() => bookTopics.id),
  questionType: mysqlEnum("questionType", ["mcq", "short_answer", "long_answer", "fill_blank", "true_false"]).notNull(),
  questionText: text("questionText").notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("medium").notNull(),
  marks: decimal("marks", { precision: 5, scale: 2 }).default("1"),
  options: json("options"), // For MCQ: [{text: "", isCorrect: bool}]
  correctAnswer: text("correctAnswer"),
  explanation: text("explanation"),
  imageUrl: varchar("imageUrl", { length: 500 }),
  createdBy: int("createdBy").references(() => users.id).notNull(),
  status: mysqlEnum("status", ["active", "archived", "draft"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Question = typeof questions.$inferSelect;
export type InsertQuestion = typeof questions.$inferInsert;

/**
 * Question Papers table
 */
export const questionPapers = mysqlTable("question_papers", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  classLevel: varchar("classLevel", { length: 50 }).notNull(),
  subject: varchar("subject", { length: 100 }).notNull(),
  totalMarks: decimal("totalMarks", { precision: 5, scale: 2 }).notNull(),
  totalTime: int("totalTime"), // in minutes
  templateName: varchar("templateName", { length: 255 }),
  isTemplate: boolean("isTemplate").default(false),
  createdBy: int("createdBy").references(() => users.id).notNull(),
  status: mysqlEnum("status", ["draft", "published", "archived"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type QuestionPaper = typeof questionPapers.$inferSelect;
export type InsertQuestionPaper = typeof questionPapers.$inferInsert;

/**
 * Question Paper Questions (linking questions to papers)
 */
export const questionPaperQuestions = mysqlTable("question_paper_questions", {
  id: int("id").autoincrement().primaryKey(),
  paperId: int("paperId").references(() => questionPapers.id).notNull(),
  questionId: int("questionId").references(() => questions.id).notNull(),
  sectionNumber: int("sectionNumber").default(1),
  questionOrder: int("questionOrder").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type QuestionPaperQuestion = typeof questionPaperQuestions.$inferSelect;
export type InsertQuestionPaperQuestion = typeof questionPaperQuestions.$inferInsert;

/**
 * Question Paper Templates
 */
export const questionPaperTemplates = mysqlTable("question_paper_templates", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  classLevel: varchar("classLevel", { length: 50 }).notNull(),
  subject: varchar("subject", { length: 100 }).notNull(),
  totalMarks: decimal("totalMarks", { precision: 5, scale: 2 }).notNull(),
  totalTime: int("totalTime"),
  configuration: json("configuration"), // {sections: [{name: "", marks: "", questionCount: "", difficulty: ""}]}
  createdBy: int("createdBy").references(() => users.id).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type QuestionPaperTemplate = typeof questionPaperTemplates.$inferSelect;
export type InsertQuestionPaperTemplate = typeof questionPaperTemplates.$inferInsert;
