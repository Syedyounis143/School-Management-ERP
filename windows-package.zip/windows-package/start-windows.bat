@echo off
setlocal enabledelayedexpansion

echo.
echo ========================================
echo School Management System - Starting
echo ========================================
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo Error: Node.js is not installed!
    echo.
    echo Please download and install Node.js from:
    echo https://nodejs.org/
    echo.
    pause
    exit /b 1
)

REM Check if dist folder exists
if not exist "dist" (
    echo Error: Application not built!
    echo.
    echo Please run: npm run build
    echo.
    pause
    exit /b 1
)

echo Starting application...
echo.
echo The application will be available at:
echo http://localhost:3000
echo.
echo Opening browser in 3 seconds...
echo.

timeout /t 3

REM Open browser
start http://localhost:3000

REM Set environment variable and start server
set NODE_ENV=production
node dist/index.js

pause
