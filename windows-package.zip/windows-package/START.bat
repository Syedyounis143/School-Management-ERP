@echo off
setlocal enabledelayedexpansion

echo.
echo ========================================
echo School Management System - Launcher
echo ========================================
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo Node.js is not installed!
    echo.
    echo Please download and install Node.js from:
    echo https://nodejs.org/
    echo.
    echo After installing Node.js, run this file again.
    pause
    exit /b 1
)

echo Node.js found. Installing dependencies...
echo.

REM Install dependencies
call npm install --legacy-peer-deps

if %errorlevel% neq 0 (
    echo.
    echo Error: Failed to install dependencies
    pause
    exit /b 1
)

echo.
echo ========================================
echo Starting application...
echo ========================================
echo.
echo The application will open in your browser at:
echo http://localhost:3000
echo.
echo Press Ctrl+C in this window to stop the application.
echo.

REM Start the application
call npm start

pause
