import { eq, and, gte, lte, desc, asc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  students,
  teachers,
  classes,
  subjects,
  teacherSubjects,
  attendance,
  exams,
  marks,
  feeStructures,
  feePayments,
  books,
  bookIssues,
  timetables,
  announcements,
  events,
  scertBooks,
  bookChapters,
  bookTopics,
  questions,
  questionPapers,
  questionPaperQuestions,
  questionPaperTemplates,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Student queries
export async function getStudentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(students).where(eq(students.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllStudents(classId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (classId) {
    return db.select().from(students).where(eq(students.classId, classId));
  }
  return db.select().from(students);
}

export async function createStudent(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(students).values(data);
  return result;
}

export async function updateStudent(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(students).set(data).where(eq(students.id, id));
}

// Teacher queries
export async function getTeacherById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(teachers).where(eq(teachers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllTeachers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(teachers);
}

export async function createTeacher(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(teachers).values(data);
}

export async function updateTeacher(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(teachers).set(data).where(eq(teachers.id, id));
}

// Class queries
export async function getClassById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(classes).where(eq(classes.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllClasses() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(classes);
}

export async function createClass(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(classes).values(data);
}

export async function updateClass(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(classes).set(data).where(eq(classes.id, id));
}

// Subject queries
export async function getAllSubjects() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(subjects);
}

export async function createSubject(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(subjects).values(data);
}

// Attendance queries
export async function getAttendanceByDate(classId: number, date: Date) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(attendance).where(
    and(eq(attendance.classId, classId), eq(attendance.date, date))
  );
}

export async function createAttendance(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(attendance).values(data);
}

export async function getStudentAttendance(studentId: number, startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(attendance).where(
    and(
      eq(attendance.studentId, studentId),
      gte(attendance.date, startDate),
      lte(attendance.date, endDate)
    )
  );
}

// Exam queries
export async function getAllExams() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(exams);
}

export async function createExam(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(exams).values(data);
}

// Marks queries
export async function getMarksByExam(examId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(marks).where(eq(marks.examId, examId));
}

export async function getStudentMarks(studentId: number, examId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(marks).where(
    and(eq(marks.studentId, studentId), eq(marks.examId, examId))
  );
}

export async function createMarks(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(marks).values(data);
}

export async function updateMarks(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(marks).set(data).where(eq(marks.id, id));
}

// Fee Structure queries
export async function getFeeStructureByClass(classId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(feeStructures).where(eq(feeStructures.classId, classId));
}

export async function createFeeStructure(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(feeStructures).values(data);
}

// Fee Payment queries
export async function getStudentFeePayments(studentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(feePayments).where(eq(feePayments.studentId, studentId));
}

export async function createFeePayment(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(feePayments).values(data);
}

// Book queries
export async function getAllBooks() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(books);
}

export async function createBook(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(books).values(data);
}

export async function updateBook(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(books).set(data).where(eq(books.id, id));
}

// Book Issue queries
export async function getStudentBookIssues(studentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bookIssues).where(eq(bookIssues.studentId, studentId));
}

export async function createBookIssue(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(bookIssues).values(data);
}

export async function updateBookIssue(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(bookIssues).set(data).where(eq(bookIssues.id, id));
}

// Timetable queries
export async function getClassTimetable(classId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(timetables).where(eq(timetables.classId, classId));
}

export async function createTimetable(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(timetables).values(data);
}

// Announcement queries
export async function getAllAnnouncements() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(announcements).orderBy(desc(announcements.publishedDate));
}

export async function createAnnouncement(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(announcements).values(data);
}

// Event queries
export async function getAllEvents() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(events).orderBy(asc(events.eventDate));
}

export async function createEvent(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(events).values(data);
}

// Teacher-Subject queries
export async function getTeacherSubjects(teacherId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(teacherSubjects).where(eq(teacherSubjects.teacherId, teacherId));
}

export async function createTeacherSubject(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(teacherSubjects).values(data);
}


// SCERT Books queries
export async function getAllScertBooks(classLevel?: string, subject?: string) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(scertBooks);
  
  if (classLevel) {
    query = query.where(eq(scertBooks.classLevel, classLevel));
  }
  if (subject) {
    query = query.where(eq(scertBooks.subject, subject));
  }
  
  return await query;
}

export async function getScertBookById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(scertBooks).where(eq(scertBooks.id, id)).limit(1);
  return result[0] || null;
}

export async function createScertBook(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(scertBooks).values(data);
}

export async function updateScertBook(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(scertBooks).set(data).where(eq(scertBooks.id, id));
}

// Book Chapters queries
export async function getBookChapters(bookId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bookChapters).where(eq(bookChapters.bookId, bookId));
}

export async function createBookChapter(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(bookChapters).values(data);
}

// Book Topics queries
export async function getBookTopics(chapterId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bookTopics).where(eq(bookTopics.chapterId, chapterId));
}

export async function createBookTopic(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(bookTopics).values(data);
}

// Questions queries
export async function getAllQuestions(filters?: any) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(questions);
  
  if (filters?.bookId) {
    query = query.where(eq(questions.bookId, filters.bookId));
  }
  if (filters?.chapterId) {
    query = query.where(eq(questions.chapterId, filters.chapterId));
  }
  if (filters?.topicId) {
    query = query.where(eq(questions.topicId, filters.topicId));
  }
  if (filters?.difficulty) {
    query = query.where(eq(questions.difficulty, filters.difficulty));
  }
  if (filters?.questionType) {
    query = query.where(eq(questions.questionType, filters.questionType));
  }
  
  return await query;
}

export async function getQuestionById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(questions).where(eq(questions.id, id)).limit(1);
  return result[0] || null;
}

export async function createQuestion(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(questions).values(data);
}

export async function updateQuestion(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(questions).set(data).where(eq(questions.id, id));
}

// Question Papers queries
export async function getAllQuestionPapers(classLevel?: string, subject?: string) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(questionPapers);
  
  if (classLevel) {
    query = query.where(eq(questionPapers.classLevel, classLevel));
  }
  if (subject) {
    query = query.where(eq(questionPapers.subject, subject));
  }
  
  return await query;
}

export async function getQuestionPaperById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(questionPapers).where(eq(questionPapers.id, id)).limit(1);
  return result[0] || null;
}

export async function createQuestionPaper(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(questionPapers).values(data);
}

export async function updateQuestionPaper(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(questionPapers).set(data).where(eq(questionPapers.id, id));
}

// Question Paper Questions queries
export async function getQuestionPaperQuestions(paperId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(questionPaperQuestions).where(eq(questionPaperQuestions.paperId, paperId));
}

export async function addQuestionToPaper(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(questionPaperQuestions).values(data);
}

// Question Paper Templates queries
export async function getAllQuestionPaperTemplates(classLevel?: string, subject?: string) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(questionPaperTemplates);
  
  if (classLevel) {
    query = query.where(eq(questionPaperTemplates.classLevel, classLevel));
  }
  if (subject) {
    query = query.where(eq(questionPaperTemplates.subject, subject));
  }
  
  return await query;
}

export async function getQuestionPaperTemplateById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(questionPaperTemplates).where(eq(questionPaperTemplates.id, id)).limit(1);
  return result[0] || null;
}

export async function createQuestionPaperTemplate(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(questionPaperTemplates).values(data);
}

export async function updateQuestionPaperTemplate(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(questionPaperTemplates).set(data).where(eq(questionPaperTemplates.id, id));
}
