import { Document, Packer, Paragraph, Table, TableRow, TableCell, WidthType, BorderStyle, AlignmentType, TextRun } from 'docx';

/**
 * PDF/Document Export Utility
 * Generates formatted reports, question papers, and receipts
 */

export interface ReportData {
  title: string;
  date: Date;
  data: Record<string, any>[];
  columns: string[];
}

export interface QuestionPaperData {
  title: string;
  class: string;
  totalMarks: number;
  duration: number;
  sections: Array<{
    name: string;
    questions: Array<{
      number: number;
      text: string;
      marks: number;
      type: string;
    }>;
  }>;
}

export interface ReceiptData {
  receiptNumber: string;
  date: Date;
  studentName: string;
  studentId: string;
  description: string;
  amount: number;
  paymentMethod: string;
  schoolName: string;
}

/**
 * Generate Performance Report Document
 */
export async function generatePerformanceReport(data: ReportData): Promise<Buffer> {
  const rows = [
    new TableRow({
      children: data.columns.map(col =>
        new TableCell({
          children: [new Paragraph(col)],
          shading: { fill: '4472C4', color: 'FFFFFF' },
        })
      ),
    }),
    ...data.data.map(row =>
      new TableRow({
        children: data.columns.map(col =>
          new TableCell({
            children: [new Paragraph(String(row[col] || '-'))],
          })
        ),
      })
    ),
  ];

  const doc = new Document({
    sections: [
      {
        children: [
          new Paragraph({
            text: data.title,
            heading: 'Heading1',
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 },
          }),
          new Paragraph({
            text: `Generated on: ${data.date.toLocaleDateString()}`,
            alignment: AlignmentType.RIGHT,
            spacing: { after: 400 },
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: rows,
            borders: {
              top: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
              bottom: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
              left: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
              right: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
              insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
              insideVertical: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
            },
          }),
        ],
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return buffer;
}

/**
 * Generate Question Paper Document
 */
export async function generateQuestionPaper(data: QuestionPaperData): Promise<Buffer> {
  const children = [
    new Paragraph({
      text: data.title,
      heading: 'Heading1',
      alignment: AlignmentType.CENTER,
      spacing: { after: 100 },
    }),
    new Paragraph({
      text: `Class: ${data.class} | Total Marks: ${data.totalMarks} | Duration: ${data.duration} minutes`,
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
    }),
  ];

  let questionNumber = 1;

  for (const section of data.sections) {
    children.push(
      new Paragraph({
        text: section.name,
        heading: 'Heading2',
        spacing: { before: 200, after: 100 },
      })
    );

    for (const question of section.questions) {
      children.push(
        new Paragraph({
          children: [
            new TextRun({
              text: `${questionNumber}. `,
              bold: true,
            }),
            new TextRun(question.text),
            new TextRun({
              text: ` [${question.marks} marks]`,
              italics: true,
            }),
          ],
          spacing: { after: 100 },
        })
      );
      questionNumber++;
    }
  }

  const doc = new Document({
    sections: [
      {
        children: children,
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return buffer;
}

/**
 * Generate Fee Receipt Document
 */
export async function generateFeeReceipt(data: ReceiptData): Promise<Buffer> {
  const doc = new Document({
    sections: [
      {
        children: [
          new Paragraph({
            text: data.schoolName,
            heading: 'Heading1',
            alignment: AlignmentType.CENTER,
            spacing: { after: 100 },
          }),
          new Paragraph({
            text: 'FEE RECEIPT',
            heading: 'Heading2',
            alignment: AlignmentType.CENTER,
            spacing: { after: 300 },
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              new TableRow({
                children: [
                  new TableCell({
                    children: [new Paragraph('Receipt Number:')],
                  }),
                  new TableCell({
                    children: [new Paragraph(data.receiptNumber)],
                  }),
                ],
              }),
              new TableRow({
                children: [
                  new TableCell({
                    children: [new Paragraph('Date:')],
                  }),
                  new TableCell({
                    children: [new Paragraph(data.date.toLocaleDateString())],
                  }),
                ],
              }),
              new TableRow({
                children: [
                  new TableCell({
                    children: [new Paragraph('Student Name:')],
                  }),
                  new TableCell({
                    children: [new Paragraph(data.studentName)],
                  }),
                ],
              }),
              new TableRow({
                children: [
                  new TableCell({
                    children: [new Paragraph('Student ID:')],
                  }),
                  new TableCell({
                    children: [new Paragraph(data.studentId)],
                  }),
                ],
              }),
              new TableRow({
                children: [
                  new TableCell({
                    children: [new Paragraph('Description:')],
                  }),
                  new TableCell({
                    children: [new Paragraph(data.description)],
                  }),
                ],
              }),
              new TableRow({
                children: [
                  new TableCell({
                    children: [new Paragraph('Amount:')],
                  }),
                  new TableCell({
                    children: [new Paragraph(`₹${data.amount.toLocaleString()}`)],
                  }),
                ],
              }),
              new TableRow({
                children: [
                  new TableCell({
                    children: [new Paragraph('Payment Method:')],
                  }),
                  new TableCell({
                    children: [new Paragraph(data.paymentMethod)],
                  }),
                ],
              }),
            ],
          }),
          new Paragraph({
            text: '',
            spacing: { after: 400 },
          }),
          new Paragraph({
            text: 'Thank you for your payment!',
            alignment: AlignmentType.CENTER,
            spacing: { after: 100 },
          }),
          new Paragraph({
            text: `Generated on: ${new Date().toLocaleString()}`,
            alignment: AlignmentType.RIGHT,
          }),
        ],
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return buffer;
}

/**
 * Generate Attendance Report
 */
export async function generateAttendanceReport(
  classname: string,
  month: string,
  attendanceData: Array<{
    studentName: string;
    rollNumber: string;
    presentDays: number;
    totalDays: number;
    percentage: number;
  }>
): Promise<Buffer> {
  const rows = [
    new TableRow({
      children: [
        new TableCell({ children: [new Paragraph('Roll No')], shading: { fill: '4472C4', color: 'FFFFFF' } }),
        new TableCell({ children: [new Paragraph('Student Name')], shading: { fill: '4472C4', color: 'FFFFFF' } }),
        new TableCell({ children: [new Paragraph('Present')], shading: { fill: '4472C4', color: 'FFFFFF' } }),
        new TableCell({ children: [new Paragraph('Total Days')], shading: { fill: '4472C4', color: 'FFFFFF' } }),
        new TableCell({ children: [new Paragraph('Percentage')], shading: { fill: '4472C4', color: 'FFFFFF' } }),
      ],
    }),
    ...attendanceData.map(row =>
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph(row.rollNumber)] }),
          new TableCell({ children: [new Paragraph(row.studentName)] }),
          new TableCell({ children: [new Paragraph(String(row.presentDays))] }),
          new TableCell({ children: [new Paragraph(String(row.totalDays))] }),
          new TableCell({ children: [new Paragraph(`${row.percentage.toFixed(1)}%`)] }),
        ],
      })
    ),
  ];

  const doc = new Document({
    sections: [
      {
        children: [
          new Paragraph({
            text: `Attendance Report - ${classname}`,
            heading: 'Heading1',
            alignment: AlignmentType.CENTER,
            spacing: { after: 100 },
          }),
          new Paragraph({
            text: `Month: ${month}`,
            alignment: AlignmentType.CENTER,
            spacing: { after: 300 },
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: rows,
            borders: {
              top: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
              bottom: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
              left: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
              right: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
              insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
              insideVertical: { style: BorderStyle.SINGLE, size: 1, color: '000000' },
            },
          }),
        ],
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return buffer;
}
