import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

// Validation schemas
const studentSchema = z.object({
  rollNumber: z.string().min(1),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  dateOfBirth: z.string().optional(),
  gender: z.enum(["male", "female", "other"]).optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zipCode: z.string().optional(),
  fatherName: z.string().optional(),
  fatherPhone: z.string().optional(),
  motherName: z.string().optional(),
  motherPhone: z.string().optional(),
  emergencyContact: z.string().optional(),
  emergencyPhone: z.string().optional(),
  enrollmentDate: z.string(),
  classId: z.number().optional(),
});

const teacherSchema = z.object({
  employeeId: z.string().min(1),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  email: z.string().email(),
  phone: z.string().min(1),
  dateOfBirth: z.string().optional(),
  gender: z.enum(["male", "female", "other"]).optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zipCode: z.string().optional(),
  qualification: z.string().optional(),
  experience: z.number().optional(),
  joiningDate: z.string(),
});

const classSchema = z.object({
  name: z.string().min(1),
  section: z.string().min(1),
  capacity: z.number().min(1),
  classTeacherId: z.number().optional(),
  academicYear: z.string().min(1),
});

const subjectSchema = z.object({
  name: z.string().min(1),
  code: z.string().min(1),
  description: z.string().optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Students
  students: router({
    list: protectedProcedure
      .input(z.object({ classId: z.number().optional(), search: z.string().optional() }).optional())
      .query(async ({ input }) => {
        const students = await db.getAllStudents(input?.classId);
        if (input?.search) {
          const search = input.search.toLowerCase();
          return students.filter(
            (s) =>
              s.firstName.toLowerCase().includes(search) ||
              s.lastName.toLowerCase().includes(search) ||
              s.rollNumber.toLowerCase().includes(search)
          );
        }
        return students;
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getStudentById(input.id);
      }),

    create: protectedProcedure
      .input(studentSchema)
      .mutation(async ({ input }) => {
        return db.createStudent({
          ...input,
          status: "active",
          dateOfBirth: input.dateOfBirth ? new Date(input.dateOfBirth) : null,
          enrollmentDate: new Date(input.enrollmentDate),
        });
      }),

    update: protectedProcedure
      .input(z.object({ id: z.number(), data: studentSchema.partial() }))
      .mutation(async ({ input }) => {
        const updateData = {
          ...input.data,
          dateOfBirth: input.data.dateOfBirth ? new Date(input.data.dateOfBirth) : undefined,
          enrollmentDate: input.data.enrollmentDate ? new Date(input.data.enrollmentDate) : undefined,
        };
        return db.updateStudent(input.id, updateData);
      }),
  }),

  // Teachers
  teachers: router({
    list: protectedProcedure
      .input(z.object({ search: z.string().optional() }).optional())
      .query(async ({ input }) => {
        const teachers = await db.getAllTeachers();
        if (input?.search) {
          const search = input.search.toLowerCase();
          return teachers.filter(
            (t) =>
              t.firstName.toLowerCase().includes(search) ||
              t.lastName.toLowerCase().includes(search) ||
              t.employeeId.toLowerCase().includes(search) ||
              t.email.toLowerCase().includes(search)
          );
        }
        return teachers;
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getTeacherById(input.id);
      }),

    create: protectedProcedure
      .input(teacherSchema)
      .mutation(async ({ input }) => {
        return db.createTeacher({
          ...input,
          status: "active",
          dateOfBirth: input.dateOfBirth ? new Date(input.dateOfBirth) : null,
          joiningDate: new Date(input.joiningDate),
        });
      }),

    update: protectedProcedure
      .input(z.object({ id: z.number(), data: teacherSchema.partial() }))
      .mutation(async ({ input }) => {
        const updateData = {
          ...input.data,
          dateOfBirth: input.data.dateOfBirth ? new Date(input.data.dateOfBirth) : undefined,
          joiningDate: input.data.joiningDate ? new Date(input.data.joiningDate) : undefined,
        };
        return db.updateTeacher(input.id, updateData);
      }),

    getSubjects: protectedProcedure
      .input(z.object({ teacherId: z.number() }))
      .query(async ({ input }) => {
        return db.getTeacherSubjects(input.teacherId);
      }),
  }),

  // Classes
  classes: router({
    list: protectedProcedure.query(async () => {
      return db.getAllClasses();
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getClassById(input.id);
      }),

    create: protectedProcedure
      .input(classSchema)
      .mutation(async ({ input }) => {
        return db.createClass(input);
      }),

    update: protectedProcedure
      .input(z.object({ id: z.number(), data: classSchema.partial() }))
      .mutation(async ({ input }) => {
        return db.updateClass(input.id, input.data);
      }),
  }),

  // Subjects
  subjects: router({
    list: protectedProcedure.query(async () => {
      return db.getAllSubjects();
    }),

    create: protectedProcedure
      .input(subjectSchema)
      .mutation(async ({ input }) => {
        return db.createSubject(input);
      }),
  }),

  // Teacher-Subject assignments
  teacherSubjects: router({
    getByTeacher: protectedProcedure
      .input(z.object({ teacherId: z.number() }))
      .query(async ({ input }) => {
        return db.getTeacherSubjects(input.teacherId);
      }),
    create: protectedProcedure
      .input(z.object({ teacherId: z.number(), subjectId: z.number(), classId: z.number() }))
      .mutation(async ({ input }) => {
        return db.createTeacherSubject(input);
      }),
  }),
  // SCERT Books
  scertBooks: router({
    list: protectedProcedure
      .input(z.object({ classLevel: z.string().optional(), subject: z.string().optional(), search: z.string().optional() }))
      .query(async ({ input }) => {
        const books = await db.getAllScertBooks(input.classLevel, input.subject);
        if (input.search) {
          return books.filter((b: any) => b.title.toLowerCase().includes(input.search?.toLowerCase() || ''));
        }
        return books;
      }),
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getScertBookById(input.id);
      }),
    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        author: z.string(),
        publisher: z.string().optional(),
        isbn: z.string().optional(),
        classLevel: z.string(),
        subject: z.string(),
        description: z.string().optional(),
        fileUrl: z.string(),
        filePath: z.string(),
        fileSize: z.number().optional(),
        totalPages: z.number().optional(),
        status: z.enum(['active', 'archived', 'draft']),
      }))
      .mutation(async ({ input, ctx }) => {
        return db.createScertBook({
          ...input,
          uploadedBy: ctx.user.id,
        });
      }),
  }),
  // Question Papers
  questionPapers: router({
    list: protectedProcedure
      .input(z.object({ classLevel: z.string().optional(), subject: z.string().optional() }))
      .query(async ({ input }) => {
        return db.getAllQuestionPapers(input.classLevel, input.subject);
      }),
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getQuestionPaperById(input.id);
      }),
    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        classLevel: z.string(),
        subject: z.string(),
        totalMarks: z.number(),
        totalTime: z.number().optional(),
        templateName: z.string().optional(),
        isTemplate: z.boolean().optional(),
        status: z.enum(['draft', 'published', 'archived']),
      }))
      .mutation(async ({ input, ctx }) => {
        return db.createQuestionPaper({
          ...input,
          createdBy: ctx.user.id,
        });
      }),
  }),
  // Questions
  questions: router({
    list: protectedProcedure
      .input(z.object({
        bookId: z.number().optional(),
        chapterId: z.number().optional(),
        topicId: z.number().optional(),
        difficulty: z.string().optional(),
        questionType: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return db.getAllQuestions(input);
      }),
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getQuestionById(input.id);
      }),
    create: protectedProcedure
      .input(z.object({
        bookId: z.number().optional(),
        chapterId: z.number().optional(),
        topicId: z.number().optional(),
        questionType: z.enum(['mcq', 'short_answer', 'long_answer', 'fill_blank', 'true_false']),
        questionText: z.string(),
        difficulty: z.enum(['easy', 'medium', 'hard']),
        marks: z.number(),
        options: z.any().optional(),
        correctAnswer: z.string().optional(),
        explanation: z.string().optional(),
        imageUrl: z.string().optional(),
        status: z.enum(['active', 'archived', 'draft']),
      }))
      .mutation(async ({ input, ctx }) => {
        return db.createQuestion({
          ...input,
          createdBy: ctx.user.id,
        });
      }),
  }),
  // PDF Export
  exports: router({
    generatePerformanceReport: protectedProcedure
      .input(z.object({
        title: z.string(),
        data: z.any(),
        columns: z.array(z.string()),
      }))
      .mutation(async ({ input }) => {
        const { generatePerformanceReport } = await import('./pdf-export');
        const buffer = await generatePerformanceReport({
          title: input.title,
          date: new Date(),
          data: input.data,
          columns: input.columns,
        });
        return { success: true, size: buffer.length };
      }),
    generateQuestionPaper: protectedProcedure
      .input(z.object({
        title: z.string(),
        class: z.string(),
        totalMarks: z.number(),
        duration: z.number(),
        sections: z.any(),
      }))
      .mutation(async ({ input }) => {
        const { generateQuestionPaper } = await import('./pdf-export');
        const buffer = await generateQuestionPaper(input);
        return { success: true, size: buffer.length };
      }),
    generateFeeReceipt: protectedProcedure
      .input(z.object({
        receiptNumber: z.string(),
        studentName: z.string(),
        studentId: z.string(),
        description: z.string(),
        amount: z.number(),
        paymentMethod: z.string(),
        schoolName: z.string(),
      }))
      .mutation(async ({ input }) => {
        const { generateFeeReceipt } = await import('./pdf-export');
        const buffer = await generateFeeReceipt({
          ...input,
          date: new Date(),
        });
        return { success: true, size: buffer.length };
      }),
  }),
  // CSV Operations
  csvOperations: router({
    parseStudentCSV: protectedProcedure
      .input(z.object({ content: z.string() }))
      .mutation(async ({ input }) => {
        const { parseStudentCSV, validateStudentData } = await import('./csv-operations');
        const data = await parseStudentCSV(input.content);
        const { valid, errors } = validateStudentData(data);
        return { valid, errors, count: valid.length };
      }),
    generateStudentCSV: protectedProcedure
      .input(z.object({ students: z.any() }))
      .query(async ({ input }) => {
        const { generateStudentCSV } = await import('./csv-operations');
        const csv = generateStudentCSV(input.students);
        return { csv, size: csv.length };
      }),
    createStudentTemplate: publicProcedure
      .query(async () => {
        const { createStudentTemplate } = await import('./csv-operations');
        return { template: createStudentTemplate() };
      }),
  }),
  // Analytics
  analytics: router({
    performanceTrends: protectedProcedure
      .input(z.object({ marks: z.any(), periodDays: z.number().optional() }))
      .query(async ({ input }) => {
        const { calculatePerformanceTrends } = await import('./advanced-analytics');
        return calculatePerformanceTrends(input.marks, input.periodDays || 30);
      }),
    attendanceTrends: protectedProcedure
      .input(z.object({ attendance: z.any(), periodDays: z.number().optional() }))
      .query(async ({ input }) => {
        const { calculateAttendanceTrends } = await import('./advanced-analytics');
        return calculateAttendanceTrends(input.attendance, input.periodDays || 30);
      }),
    feeTrends: protectedProcedure
      .input(z.object({ payments: z.any(), periodDays: z.number().optional() }))
      .query(async ({ input }) => {
        const { calculateFeeTrends } = await import('./advanced-analytics');
        return calculateFeeTrends(input.payments, input.periodDays || 30);
      }),
    classAnalytics: protectedProcedure
      .input(z.object({ className: z.string(), students: z.any() }))
      .query(async ({ input }) => {
        const { generateClassAnalytics } = await import('./advanced-analytics');
        return generateClassAnalytics(input.className, input.students);
      }),
    atRiskStudents: protectedProcedure
      .input(z.object({ students: z.any() }))
      .query(async ({ input }) => {
        const { identifyAtRiskStudents } = await import('./advanced-analytics');
        return identifyAtRiskStudents(input.students);
      }),
    customReport: protectedProcedure
      .input(z.object({
        reportType: z.enum(['performance', 'attendance', 'fees', 'comprehensive']),
        data: z.any(),
        filters: z.any().optional(),
      }))
      .query(async ({ input }) => {
        const { generateCustomReport } = await import('./advanced-analytics');
        return generateCustomReport(input.reportType, input.data, input.filters);
      }),
  }),
});;

export type AppRouter = typeof appRouter;
