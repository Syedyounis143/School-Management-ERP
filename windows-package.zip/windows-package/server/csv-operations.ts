import Papa from 'papaparse';
import { createWriteStream } from 'fs';
import { join } from 'path';

/**
 * CSV Import/Export Utility
 * Handles bulk operations for students, teachers, marks, and fees
 */

export interface StudentImportData {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  dateOfBirth: string;
  gender: string;
  address: string;
  classId: string;
  rollNumber: string;
}

export interface TeacherImportData {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  subject: string;
  qualification: string;
  experience: string;
}

export interface MarksImportData {
  studentId: string;
  examId: string;
  subject: string;
  marksObtained: string;
  totalMarks: string;
}

export interface FeeImportData {
  studentId: string;
  classId: string;
  tuitionFee: string;
  transportFee: string;
  uniformFee: string;
  totalFee: string;
}

/**
 * Parse CSV file for students
 */
export async function parseStudentCSV(csvContent: string): Promise<StudentImportData[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(csvContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results: any) => {
        const validatedData = (results.data as any[]).map(row => ({
          firstName: row.firstName?.trim() || '',
          lastName: row.lastName?.trim() || '',
          email: row.email?.trim() || '',
          phoneNumber: row.phoneNumber?.trim() || '',
          dateOfBirth: row.dateOfBirth?.trim() || '',
          gender: row.gender?.trim() || '',
          address: row.address?.trim() || '',
          classId: row.classId?.trim() || '',
          rollNumber: row.rollNumber?.trim() || '',
        }));
        resolve(validatedData);
      },
      error: (error: any) => reject(error),
    });
  });
}

/**
 * Parse CSV file for teachers
 */
export async function parseTeacherCSV(csvContent: string): Promise<TeacherImportData[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(csvContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results: any) => {
        const validatedData = (results.data as any[]).map(row => ({
          firstName: row.firstName?.trim() || '',
          lastName: row.lastName?.trim() || '',
          email: row.email?.trim() || '',
          phoneNumber: row.phoneNumber?.trim() || '',
          subject: row.subject?.trim() || '',
          qualification: row.qualification?.trim() || '',
          experience: row.experience?.trim() || '',
        }));
        resolve(validatedData);
      },
      error: (error: any) => reject(error),
    });
  });
}

/**
 * Parse CSV file for marks
 */
export async function parseMarksCSV(csvContent: string): Promise<MarksImportData[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(csvContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results: any) => {
        const validatedData = (results.data as any[]).map(row => ({
          studentId: row.studentId?.trim() || '',
          examId: row.examId?.trim() || '',
          subject: row.subject?.trim() || '',
          marksObtained: row.marksObtained?.trim() || '',
          totalMarks: row.totalMarks?.trim() || '',
        }));
        resolve(validatedData);
      },
      error: (error: any) => reject(error),
    });
  });
}

/**
 * Parse CSV file for fees
 */
export async function parseFeeCSV(csvContent: string): Promise<FeeImportData[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(csvContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results: any) => {
        const validatedData = (results.data as any[]).map(row => ({
          studentId: row.studentId?.trim() || '',
          classId: row.classId?.trim() || '',
          tuitionFee: row.tuitionFee?.trim() || '',
          transportFee: row.transportFee?.trim() || '',
          uniformFee: row.uniformFee?.trim() || '',
          totalFee: row.totalFee?.trim() || '',
        }));
        resolve(validatedData);
      },
      error: (error: any) => reject(error),
    });
  });
}

/**
 * Generate CSV for students
 */
export function generateStudentCSV(students: any[]): string {
  const headers = ['firstName', 'lastName', 'email', 'phoneNumber', 'dateOfBirth', 'gender', 'address', 'classId', 'rollNumber'];
  const csv = Papa.unparse({
    fields: headers,
    data: students.map(s => [
      s.firstName,
      s.lastName,
      s.email,
      s.phoneNumber,
      s.dateOfBirth,
      s.gender,
      s.address,
      s.classId,
      s.rollNumber,
    ]),
  });
  return csv;
}

/**
 * Generate CSV for teachers
 */
export function generateTeacherCSV(teachers: any[]): string {
  const headers = ['firstName', 'lastName', 'email', 'phoneNumber', 'subject', 'qualification', 'experience'];
  const csv = Papa.unparse({
    fields: headers,
    data: teachers.map(t => [
      t.firstName,
      t.lastName,
      t.email,
      t.phoneNumber,
      t.subject,
      t.qualification,
      t.experience,
    ]),
  });
  return csv;
}

/**
 * Generate CSV for marks
 */
export function generateMarksCSV(marks: any[]): string {
  const headers = ['studentId', 'examId', 'subject', 'marksObtained', 'totalMarks'];
  const csv = Papa.unparse({
    fields: headers,
    data: marks.map(m => [
      m.studentId,
      m.examId,
      m.subject,
      m.marksObtained,
      m.totalMarks,
    ]),
  });
  return csv;
}

/**
 * Generate CSV for attendance
 */
export function generateAttendanceCSV(attendance: any[]): string {
  const headers = ['studentId', 'date', 'status', 'remarks'];
  const csv = Papa.unparse({
    fields: headers,
    data: attendance.map(a => [
      a.studentId,
      new Date(a.date).toLocaleDateString(),
      a.status,
      a.remarks || '',
    ]),
  });
  return csv;
}

/**
 * Generate CSV for fees
 */
export function generateFeeCSV(fees: any[]): string {
  const headers = ['studentId', 'classId', 'tuitionFee', 'transportFee', 'uniformFee', 'totalFee', 'paid', 'due'];
  const csv = Papa.unparse({
    fields: headers,
    data: fees.map(f => [
      f.studentId,
      f.classId,
      f.tuitionFee,
      f.transportFee,
      f.uniformFee,
      f.totalFee,
      f.paid || 0,
      (f.totalFee - (f.paid || 0)),
    ]),
  });
  return csv;
}

/**
 * Generate CSV for library transactions
 */
export function generateLibraryCSV(transactions: any[]): string {
  const headers = ['bookId', 'studentId', 'issueDate', 'dueDate', 'returnDate', 'status', 'fine'];
  const csv = Papa.unparse({
    fields: headers,
    data: transactions.map(t => [
      t.bookId,
      t.studentId,
      new Date(t.issueDate).toLocaleDateString(),
      new Date(t.dueDate).toLocaleDateString(),
      t.returnDate ? new Date(t.returnDate).toLocaleDateString() : '',
      t.status,
      t.fine || 0,
    ]),
  });
  return csv;
}

/**
 * Validate student import data
 */
export function validateStudentData(data: StudentImportData[]): { valid: StudentImportData[]; errors: string[] } {
  const errors: string[] = [];
  const valid: StudentImportData[] = [];

  data.forEach((row, index) => {
    const rowErrors: string[] = [];

    if (!row.firstName?.trim()) rowErrors.push(`Row ${index + 1}: First name is required`);
    if (!row.lastName?.trim()) rowErrors.push(`Row ${index + 1}: Last name is required`);
    if (!row.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.email)) rowErrors.push(`Row ${index + 1}: Invalid email`);
    if (!row.phoneNumber?.trim() || !/^\d{10}$/.test(row.phoneNumber)) rowErrors.push(`Row ${index + 1}: Phone must be 10 digits`);
    if (!row.classId?.trim()) rowErrors.push(`Row ${index + 1}: Class ID is required`);
    if (!row.rollNumber?.trim()) rowErrors.push(`Row ${index + 1}: Roll number is required`);

    if (rowErrors.length === 0) {
      valid.push(row);
    } else {
      errors.push(...rowErrors);
    }
  });

  return { valid, errors };
}

/**
 * Validate teacher import data
 */
export function validateTeacherData(data: TeacherImportData[]): { valid: TeacherImportData[]; errors: string[] } {
  const errors: string[] = [];
  const valid: TeacherImportData[] = [];

  data.forEach((row, index) => {
    const rowErrors: string[] = [];

    if (!row.firstName?.trim()) rowErrors.push(`Row ${index + 1}: First name is required`);
    if (!row.lastName?.trim()) rowErrors.push(`Row ${index + 1}: Last name is required`);
    if (!row.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.email)) rowErrors.push(`Row ${index + 1}: Invalid email`);
    if (!row.phoneNumber?.trim() || !/^\d{10}$/.test(row.phoneNumber)) rowErrors.push(`Row ${index + 1}: Phone must be 10 digits`);
    if (!row.subject?.trim()) rowErrors.push(`Row ${index + 1}: Subject is required`);

    if (rowErrors.length === 0) {
      valid.push(row);
    } else {
      errors.push(...rowErrors);
    }
  });

  return { valid, errors };
}

/**
 * Validate marks import data
 */
export function validateMarksData(data: MarksImportData[]): { valid: MarksImportData[]; errors: string[] } {
  const errors: string[] = [];
  const valid: MarksImportData[] = [];

  data.forEach((row, index) => {
    const rowErrors: string[] = [];

    if (!row.studentId?.trim()) rowErrors.push(`Row ${index + 1}: Student ID is required`);
    if (!row.examId?.trim()) rowErrors.push(`Row ${index + 1}: Exam ID is required`);
    if (!row.marksObtained?.trim() || isNaN(Number(row.marksObtained))) rowErrors.push(`Row ${index + 1}: Marks must be a number`);
    if (!row.totalMarks?.trim() || isNaN(Number(row.totalMarks))) rowErrors.push(`Row ${index + 1}: Total marks must be a number`);

    if (rowErrors.length === 0) {
      valid.push(row);
    } else {
      errors.push(...rowErrors);
    }
  });

  return { valid, errors };
}

/**
 * Create sample CSV template for students
 */
export function createStudentTemplate(): string {
  const template = `firstName,lastName,email,phoneNumber,dateOfBirth,gender,address,classId,rollNumber
Aarav,Kumar,aarav@example.com,9876543210,2010-05-15,Male,123 Main St,1,A001
Priya,Sharma,priya@example.com,9876543211,2010-06-20,Female,456 Oak Ave,1,A002
Rohan,Patel,rohan@example.com,9876543212,2010-07-10,Male,789 Pine Rd,1,A003`;
  return template;
}

/**
 * Create sample CSV template for teachers
 */
export function createTeacherTemplate(): string {
  const template = `firstName,lastName,email,phoneNumber,subject,qualification,experience
Rajesh,Singh,rajesh@school.com,9876543220,Mathematics,B.Sc B.Ed,5
Anjali,Verma,anjali@school.com,9876543221,English,M.A B.Ed,8
Vikram,Gupta,vikram@school.com,9876543222,Science,B.Sc B.Ed,3`;
  return template;
}

/**
 * Create sample CSV template for marks
 */
export function createMarksTemplate(): string {
  const template = `studentId,examId,subject,marksObtained,totalMarks
1,1,Mathematics,85,100
1,1,English,78,100
2,1,Mathematics,92,100
2,1,English,88,100`;
  return template;
}
