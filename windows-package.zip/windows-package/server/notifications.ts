/**
 * Real-time Notifications System
 * Handles WebSocket-based notifications for fees, attendance, exams, and events
 */

export interface Notification {
  id: string;
  userId: number;
  type: 'fee' | 'attendance' | 'exam' | 'event' | 'announcement';
  title: string;
  message: string;
  data: Record<string, any>;
  read: boolean;
  createdAt: Date;
  expiresAt?: Date;
}

export interface NotificationPreference {
  userId: number;
  feeAlerts: boolean;
  attendanceAlerts: boolean;
  examAlerts: boolean;
  eventAlerts: boolean;
  announcementAlerts: boolean;
  emailNotifications: boolean;
  smsNotifications: boolean;
}

export class NotificationManager {
  private notifications: Map<number, Notification[]> = new Map();
  private subscribers: Map<number, Set<(notification: Notification) => void>> = new Map();

  /**
   * Create fee payment notification
   */
  createFeeNotification(userId: number, studentName: string, amount: number, dueDate: Date): Notification {
    const notification: Notification = {
      id: `fee-${Date.now()}`,
      userId,
      type: 'fee',
      title: 'Fee Payment Due',
      message: `Fee payment of ₹${amount} for ${studentName} is due on ${dueDate.toLocaleDateString()}`,
      data: {
        studentName,
        amount,
        dueDate,
        type: 'payment_due',
      },
      read: false,
      createdAt: new Date(),
      expiresAt: dueDate,
    };

    this.storeNotification(notification);
    this.broadcastNotification(userId, notification);
    return notification;
  }

  /**
   * Create attendance notification
   */
  createAttendanceNotification(userId: number, studentName: string, attendancePercentage: number): Notification {
    const notification: Notification = {
      id: `attendance-${Date.now()}`,
      userId,
      type: 'attendance',
      title: 'Low Attendance Alert',
      message: `${studentName}'s attendance is ${attendancePercentage.toFixed(1)}%. Please improve attendance.`,
      data: {
        studentName,
        attendancePercentage,
        threshold: 75,
      },
      read: false,
      createdAt: new Date(),
    };

    this.storeNotification(notification);
    this.broadcastNotification(userId, notification);
    return notification;
  }

  /**
   * Create exam result notification
   */
  createExamNotification(userId: number, studentName: string, examName: string, marks: number, totalMarks: number): Notification {
    const percentage = (marks / totalMarks) * 100;
    const notification: Notification = {
      id: `exam-${Date.now()}`,
      userId,
      type: 'exam',
      title: 'Exam Results Published',
      message: `${studentName} scored ${marks}/${totalMarks} (${percentage.toFixed(1)}%) in ${examName}`,
      data: {
        studentName,
        examName,
        marks,
        totalMarks,
        percentage,
      },
      read: false,
      createdAt: new Date(),
    };

    this.storeNotification(notification);
    this.broadcastNotification(userId, notification);
    return notification;
  }

  /**
   * Create event notification
   */
  createEventNotification(userId: number, eventName: string, eventDate: Date, location: string): Notification {
    const notification: Notification = {
      id: `event-${Date.now()}`,
      userId,
      type: 'event',
      title: 'Upcoming Event',
      message: `${eventName} is scheduled on ${eventDate.toLocaleDateString()} at ${location}`,
      data: {
        eventName,
        eventDate,
        location,
      },
      read: false,
      createdAt: new Date(),
    };

    this.storeNotification(notification);
    this.broadcastNotification(userId, notification);
    return notification;
  }

  /**
   * Create announcement notification
   */
  createAnnouncementNotification(userId: number, title: string, content: string): Notification {
    const notification: Notification = {
      id: `announcement-${Date.now()}`,
      userId,
      type: 'announcement',
      title: title,
      message: content,
      data: {
        content,
      },
      read: false,
      createdAt: new Date(),
    };

    this.storeNotification(notification);
    this.broadcastNotification(userId, notification);
    return notification;
  }

  /**
   * Store notification
   */
  private storeNotification(notification: Notification): void {
    if (!this.notifications.has(notification.userId)) {
      this.notifications.set(notification.userId, []);
    }
    this.notifications.get(notification.userId)!.push(notification);
  }

  /**
   * Broadcast notification to subscribers
   */
  private broadcastNotification(userId: number, notification: Notification): void {
    const subscribers = this.subscribers.get(userId);
    if (subscribers) {
      subscribers.forEach(callback => {
        try {
          callback(notification);
        } catch (error) {
          console.error('Error broadcasting notification:', error);
        }
      });
    }
  }

  /**
   * Subscribe to notifications
   */
  subscribe(userId: number, callback: (notification: Notification) => void): () => void {
    if (!this.subscribers.has(userId)) {
      this.subscribers.set(userId, new Set());
    }
    this.subscribers.get(userId)!.add(callback);

    // Return unsubscribe function
    return () => {
      this.subscribers.get(userId)?.delete(callback);
    };
  }

  /**
   * Get all notifications for user
   */
  getNotifications(userId: number, unreadOnly: boolean = false): Notification[] {
    const userNotifications = this.notifications.get(userId) || [];
    if (unreadOnly) {
      return userNotifications.filter(n => !n.read);
    }
    return userNotifications;
  }

  /**
   * Mark notification as read
   */
  markAsRead(userId: number, notificationId: string): void {
    const userNotifications = this.notifications.get(userId);
    if (userNotifications) {
      const notification = userNotifications.find(n => n.id === notificationId);
      if (notification) {
        notification.read = true;
      }
    }
  }

  /**
   * Mark all notifications as read
   */
  markAllAsRead(userId: number): void {
    const userNotifications = this.notifications.get(userId);
    if (userNotifications) {
      userNotifications.forEach(n => (n.read = true));
    }
  }

  /**
   * Delete notification
   */
  deleteNotification(userId: number, notificationId: string): void {
    const userNotifications = this.notifications.get(userId);
    if (userNotifications) {
      const index = userNotifications.findIndex(n => n.id === notificationId);
      if (index > -1) {
        userNotifications.splice(index, 1);
      }
    }
  }

  /**
   * Clear expired notifications
   */
  clearExpiredNotifications(): void {
    const now = new Date();
    this.notifications.forEach((notifications, userId) => {
      this.notifications.set(
        userId,
        notifications.filter((n: Notification) => !n.expiresAt || n.expiresAt > now)
      );
    });
  }

  /**
   * Get unread count
   */
  getUnreadCount(userId: number): number {
    const userNotifications = this.notifications.get(userId) || [];
    return userNotifications.filter(n => !n.read).length;
  }

  /**
   * Bulk create fee notifications
   */
  createBulkFeeNotifications(userIds: number[], studentName: string, amount: number, dueDate: Date): Notification[] {
    return userIds.map(userId => this.createFeeNotification(userId, studentName, amount, dueDate));
  }

  /**
   * Bulk create attendance notifications
   */
  createBulkAttendanceNotifications(userIds: number[], lowAttendanceStudents: Array<{ studentName: string; percentage: number }>): Notification[] {
    const notifications: Notification[] = [];
    for (const userId of userIds) {
      for (const student of lowAttendanceStudents) {
        notifications.push(this.createAttendanceNotification(userId, student.studentName, student.percentage));
      }
    }
    return notifications;
  }

  /**
   * Bulk create exam notifications
   */
  createBulkExamNotifications(userIds: number[], examResults: Array<{ studentName: string; examName: string; marks: number; totalMarks: number }>): Notification[] {
    const notifications: Notification[] = [];
    for (const userId of userIds) {
      for (const result of examResults) {
        notifications.push(this.createExamNotification(userId, result.studentName, result.examName, result.marks, result.totalMarks));
      }
    }
    return notifications;
  }
}

/**
 * Global notification manager instance
 */
export const notificationManager = new NotificationManager();

/**
 * Notification type guards
 */
export function isFeeNotification(notification: Notification): boolean {
  return notification.type === 'fee';
}

export function isAttendanceNotification(notification: Notification): boolean {
  return notification.type === 'attendance';
}

export function isExamNotification(notification: Notification): boolean {
  return notification.type === 'exam';
}

export function isEventNotification(notification: Notification): boolean {
  return notification.type === 'event';
}

export function isAnnouncementNotification(notification: Notification): boolean {
  return notification.type === 'announcement';
}
