/**
 * Advanced Analytics & Trends
 * Provides performance trends, predictions, and advanced reporting
 */

export interface PerformanceTrend {
  period: string;
  average: number;
  highest: number;
  lowest: number;
  count: number;
}

export interface AttendanceTrend {
  period: string;
  presentPercentage: number;
  absentPercentage: number;
  leavePercentage: number;
}

export interface FeeTrend {
  period: string;
  totalDue: number;
  totalPaid: number;
  collectionRate: number;
  pendingAmount: number;
}

export interface StudentPrediction {
  studentId: number;
  studentName: string;
  riskLevel: 'low' | 'medium' | 'high';
  predictedGrade: string;
  attendanceRisk: boolean;
  feePaymentRisk: boolean;
  recommendations: string[];
}

export interface ClassAnalytics {
  className: string;
  totalStudents: number;
  averagePercentage: number;
  passPercentage: number;
  failPercentage: number;
  topPerformer: { name: string; percentage: number };
  bottomPerformer: { name: string; percentage: number };
  trend: PerformanceTrend[];
}

/**
 * Calculate performance trends over time
 */
export function calculatePerformanceTrends(
  marks: Array<{
    date: Date;
    marks: number;
    totalMarks: number;
  }>,
  periodDays: number = 30
): PerformanceTrend[] {
  const trends: PerformanceTrend[] = [];
  const now = new Date();

  for (let i = 0; i < 3; i++) {
    const periodStart = new Date(now.getTime() - (i + 1) * periodDays * 24 * 60 * 60 * 1000);
    const periodEnd = new Date(now.getTime() - i * periodDays * 24 * 60 * 60 * 1000);

    const periodMarks = marks.filter(m => m.date >= periodStart && m.date < periodEnd);

    if (periodMarks.length > 0) {
      const percentages = periodMarks.map(m => (m.marks / m.totalMarks) * 100);
      const average = percentages.reduce((a, b) => a + b, 0) / percentages.length;

      trends.push({
        period: `${periodStart.toLocaleDateString()} - ${periodEnd.toLocaleDateString()}`,
        average: Math.round(average * 100) / 100,
        highest: Math.max(...percentages),
        lowest: Math.min(...percentages),
        count: periodMarks.length,
      });
    }
  }

  return trends;
}

/**
 * Calculate attendance trends
 */
export function calculateAttendanceTrends(
  attendance: Array<{
    date: Date;
    status: 'present' | 'absent' | 'leave';
  }>,
  periodDays: number = 30
): AttendanceTrend[] {
  const trends: AttendanceTrend[] = [];
  const now = new Date();

  for (let i = 0; i < 3; i++) {
    const periodStart = new Date(now.getTime() - (i + 1) * periodDays * 24 * 60 * 60 * 1000);
    const periodEnd = new Date(now.getTime() - i * periodDays * 24 * 60 * 60 * 1000);

    const periodAttendance = attendance.filter(a => a.date >= periodStart && a.date < periodEnd);

    if (periodAttendance.length > 0) {
      const present = periodAttendance.filter(a => a.status === 'present').length;
      const absent = periodAttendance.filter(a => a.status === 'absent').length;
      const leave = periodAttendance.filter(a => a.status === 'leave').length;
      const total = periodAttendance.length;

      trends.push({
        period: `${periodStart.toLocaleDateString()} - ${periodEnd.toLocaleDateString()}`,
        presentPercentage: (present / total) * 100,
        absentPercentage: (absent / total) * 100,
        leavePercentage: (leave / total) * 100,
      });
    }
  }

  return trends;
}

/**
 * Calculate fee payment trends
 */
export function calculateFeeTrends(
  payments: Array<{
    date: Date;
    totalFee: number;
    paidAmount: number;
  }>,
  periodDays: number = 30
): FeeTrend[] {
  const trends: FeeTrend[] = [];
  const now = new Date();

  for (let i = 0; i < 3; i++) {
    const periodStart = new Date(now.getTime() - (i + 1) * periodDays * 24 * 60 * 60 * 1000);
    const periodEnd = new Date(now.getTime() - i * periodDays * 24 * 60 * 60 * 1000);

    const periodPayments = payments.filter(p => p.date >= periodStart && p.date < periodEnd);

    if (periodPayments.length > 0) {
      const totalDue = periodPayments.reduce((sum, p) => sum + p.totalFee, 0);
      const totalPaid = periodPayments.reduce((sum, p) => sum + p.paidAmount, 0);
      const collectionRate = (totalPaid / totalDue) * 100;
      const pendingAmount = totalDue - totalPaid;

      trends.push({
        period: `${periodStart.toLocaleDateString()} - ${periodEnd.toLocaleDateString()}`,
        totalDue,
        totalPaid,
        collectionRate: Math.round(collectionRate * 100) / 100,
        pendingAmount,
      });
    }
  }

  return trends;
}

/**
 * Predict student performance risk
 */
export function predictStudentRisk(
  studentData: {
    marks: number[];
    attendance: number;
    feesPaid: number;
    feesTotal: number;
  }
): StudentPrediction {
  const recommendations: string[] = [];
  let riskLevel: 'low' | 'medium' | 'high' = 'low';

  // Calculate average marks
  const avgMarks = studentData.marks.length > 0 ? studentData.marks.reduce((a, b) => a + b, 0) / studentData.marks.length : 0;

  // Determine grade
  let predictedGrade = 'F';
  if (avgMarks >= 90) predictedGrade = 'A';
  else if (avgMarks >= 80) predictedGrade = 'B';
  else if (avgMarks >= 70) predictedGrade = 'C';
  else if (avgMarks >= 60) predictedGrade = 'D';

  // Check attendance risk
  const attendanceRisk = studentData.attendance < 75;
  if (attendanceRisk) {
    riskLevel = 'high';
    recommendations.push('Improve attendance - current attendance is below 75%');
  }

  // Check fee payment risk
  const feePaymentRisk = studentData.feesPaid < studentData.feesTotal * 0.5;
  if (feePaymentRisk) {
    riskLevel = riskLevel === 'high' ? 'high' : 'medium';
    recommendations.push('Complete pending fee payments');
  }

  // Check marks trend
  if (avgMarks < 60) {
    riskLevel = 'high';
    recommendations.push('Seek academic support - marks are below passing threshold');
  } else if (avgMarks < 70) {
    riskLevel = riskLevel === 'high' ? 'high' : 'medium';
    recommendations.push('Focus on improving academic performance');
  }

  return {
    studentId: 0,
    studentName: '',
    riskLevel,
    predictedGrade,
    attendanceRisk,
    feePaymentRisk,
    recommendations,
  };
}

/**
 * Generate class analytics
 */
export function generateClassAnalytics(
  className: string,
  students: Array<{
    name: string;
    marks: number[];
    totalMarks: number;
  }>
): ClassAnalytics {
  const studentPercentages = students.map(s => ({
    name: s.name,
    percentage: s.marks.length > 0 ? (s.marks.reduce((a, b) => a + b, 0) / (s.marks.length * s.totalMarks)) * 100 : 0,
  }));

  const averagePercentage = studentPercentages.length > 0 ? studentPercentages.reduce((sum, s) => sum + s.percentage, 0) / studentPercentages.length : 0;

  const passCount = studentPercentages.filter(s => s.percentage >= 60).length;
  const failCount = studentPercentages.filter(s => s.percentage < 60).length;

  const topPerformer = studentPercentages.reduce((prev, current) => (prev.percentage > current.percentage ? prev : current), { name: '', percentage: 0 });

  const bottomPerformer = studentPercentages.reduce((prev, current) => (prev.percentage < current.percentage ? prev : current), { name: '', percentage: 100 });

  return {
    className,
    totalStudents: students.length,
    averagePercentage: Math.round(averagePercentage * 100) / 100,
    passPercentage: (passCount / students.length) * 100,
    failPercentage: (failCount / students.length) * 100,
    topPerformer,
    bottomPerformer,
    trend: [],
  };
}

/**
 * Identify at-risk students
 */
export function identifyAtRiskStudents(
  students: Array<{
    id: number;
    name: string;
    marks: number[];
    attendance: number;
    feesPaid: number;
    feesTotal: number;
  }>
): StudentPrediction[] {
  return students
    .map(student => {
      const prediction = predictStudentRisk({
        marks: student.marks,
        attendance: student.attendance,
        feesPaid: student.feesPaid,
        feesTotal: student.feesTotal,
      });

      return {
        ...prediction,
        studentId: student.id,
        studentName: student.name,
      };
    })
    .filter(p => p.riskLevel === 'high' || p.riskLevel === 'medium');
}

/**
 * Generate custom report
 */
export function generateCustomReport(
  reportType: 'performance' | 'attendance' | 'fees' | 'comprehensive',
  data: any,
  filters?: {
    startDate?: Date;
    endDate?: Date;
    className?: string;
    studentId?: number;
  }
): Record<string, any> {
  const report: Record<string, any> = {
    reportType,
    generatedAt: new Date(),
    filters,
    data: {},
  };

  switch (reportType) {
    case 'performance':
      report.data = {
        trends: calculatePerformanceTrends(data.marks || []),
        classAnalytics: data.classAnalytics || [],
        atRiskStudents: identifyAtRiskStudents(data.students || []),
      };
      break;

    case 'attendance':
      report.data = {
        trends: calculateAttendanceTrends(data.attendance || []),
        averageAttendance: data.attendance ? (data.attendance.filter((a: any) => a.status === 'present').length / data.attendance.length) * 100 : 0,
      };
      break;

    case 'fees':
      report.data = {
        trends: calculateFeeTrends(data.payments || []),
        totalCollected: data.payments ? data.payments.reduce((sum: number, p: any) => sum + p.paidAmount, 0) : 0,
        totalDue: data.payments ? data.payments.reduce((sum: number, p: any) => sum + (p.totalFee - p.paidAmount), 0) : 0,
      };
      break;

    case 'comprehensive':
      report.data = {
        performance: {
          trends: calculatePerformanceTrends(data.marks || []),
          atRiskStudents: identifyAtRiskStudents(data.students || []),
        },
        attendance: {
          trends: calculateAttendanceTrends(data.attendance || []),
        },
        fees: {
          trends: calculateFeeTrends(data.payments || []),
        },
      };
      break;
  }

  return report;
}

/**
 * Export report to CSV format
 */
export function exportReportToCSV(report: Record<string, any>): string {
  let csv = `Report Type,${report.reportType}\n`;
  csv += `Generated At,${report.generatedAt}\n\n`;

  if (report.data.trends) {
    csv += 'Period,Average,Highest,Lowest,Count\n';
    report.data.trends.forEach((trend: any) => {
      csv += `${trend.period},${trend.average},${trend.highest},${trend.lowest},${trend.count}\n`;
    });
  }

  return csv;
}
