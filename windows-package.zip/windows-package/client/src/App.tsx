import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import SchoolDashboardLayout from "./components/SchoolDashboardLayout";
import Dashboard from "./pages/Dashboard";
import StudentList from "./pages/Students/StudentList";
import AddStudent from "./pages/Students/AddStudent";
import StudentRecords from "./pages/Students/StudentRecords";
import TeacherList from "./pages/Teachers/TeacherList";
import AddTeacher from "./pages/Teachers/AddTeacher";
import ClassList from "./pages/Classes/ClassList";
import AddClass from "./pages/Classes/AddClass";
import ClassSections from "./pages/Classes/ClassSections";
import MarkAttendance from "./pages/Attendance/MarkAttendance";
import AttendanceReports from "./pages/Attendance/AttendanceReports";
import Exams from "./pages/Academics/Exams";
import MarksEntry from "./pages/Academics/MarksEntry";
import ReportCards from "./pages/Academics/ReportCards";
import Performance from "./pages/Academics/Performance";
import FeeStructure from "./pages/Finance/FeeStructure";
import FeePayments from "./pages/Finance/FeePayments";
import Receipts from "./pages/Finance/Receipts";
import BookCatalog from "./pages/Library/BookCatalog";
import BookTransactions from "./pages/Library/BookTransactions";
import Timetable from "./pages/Timetable";
import Announcements from "./pages/Announcements/Announcements";
import CreateAnnouncement from "./pages/Announcements/CreateAnnouncement";
import Events from "./pages/Announcements/Events";
import StudentPerformanceReport from "./pages/Reports/StudentPerformanceReport";
import AttendanceSummaryReport from "./pages/Reports/AttendanceSummaryReport";
import FinancialReport from "./pages/Reports/FinancialReport";
import Settings from "./pages/Settings";
import BookList from "./pages/SCERTBooks/BookList";
import UploadBook from "./pages/SCERTBooks/UploadBook";
import QuestionPaperGenerator from "./pages/SCERTBooks/QuestionPaperGenerator";
import ClassManagement from "./pages/Classes/ClassManagement";
import AttendanceMarkingSystem from "./pages/Attendance/AttendanceMarkingSystem";
import GradesManagement from "./pages/Academics/GradesManagement";
import FeeManagementDashboard from "./pages/Finance/FeeManagementDashboard";
import LibraryManagement from "./pages/Library/LibraryManagement";
import TimetableBuilder from "./pages/Timetable/TimetableBuilder";
import AnnouncementsHub from "./pages/Announcements/AnnouncementsHub";
import ComprehensiveDashboard from "./pages/Reports/ComprehensiveDashboard";

function DashboardRouter() {
  return (
    <SchoolDashboardLayout>
      <Switch>
        <Route path="/dashboard" component={Dashboard} />
        
        {/* Students */}
        <Route path="/students" component={StudentList} />
        <Route path="/students/add" component={AddStudent} />
        <Route path="/students/records" component={StudentRecords} />
        
        {/* Teachers */}
        <Route path="/teachers" component={TeacherList} />
        <Route path="/teachers/add" component={AddTeacher} />
        
        {/* Classes */}
        <Route path="/classes" component={ClassList} />
        <Route path="/classes/add" component={AddClass} />
        <Route path="/classes/sections" component={ClassSections} />
        
        {/* Attendance */}
        <Route path="/attendance/mark" component={MarkAttendance} />
        <Route path="/attendance/reports" component={AttendanceReports} />
        
        {/* Academics */}
        <Route path="/academics/exams" component={Exams} />
        <Route path="/academics/marks" component={MarksEntry} />
        <Route path="/academics/report-cards" component={ReportCards} />
        <Route path="/academics/performance" component={Performance} />
        
        {/* Finance */}
        <Route path="/finance/fee-structure" component={FeeStructure} />
        <Route path="/finance/payments" component={FeePayments} />
        <Route path="/finance/receipts" component={Receipts} />
        
        {/* Library */}
        <Route path="/library/books" component={BookCatalog} />
        <Route path="/library/transactions" component={BookTransactions} />
        
        {/* Timetable */}
        <Route path="/timetable" component={Timetable} />
        
        {/* Announcements */}
        <Route path="/announcements" component={Announcements} />
        <Route path="/announcements/create" component={CreateAnnouncement} />
        <Route path="/announcements/events" component={Events} />
        
        {/* Reports */}
        <Route path="/reports/performance" component={StudentPerformanceReport} />
        <Route path="/reports/attendance" component={AttendanceSummaryReport} />
        <Route path="/reports/financial" component={FinancialReport} />
        
        {/* Settings */}
        <Route path="/settings" component={Settings} />
        
        {/* SCERT Books */}
        <Route path="/scert-books" component={BookList} />
        <Route path="/scert-books/upload" component={UploadBook} />
        <Route path="/scert-books/question-papers" component={QuestionPaperGenerator} />
        
        {/* Updated Routes */}
        <Route path="/classes" component={ClassManagement} />
        <Route path="/attendance/mark" component={AttendanceMarkingSystem} />
        <Route path="/academics/exams" component={GradesManagement} />
        <Route path="/finance/fee-structure" component={FeeManagementDashboard} />
        <Route path="/library/books" component={LibraryManagement} />
        <Route path="/timetable" component={TimetableBuilder} />
        <Route path="/announcements" component={AnnouncementsHub} />
        <Route path="/reports/performance" component={ComprehensiveDashboard} />
        
        <Route component={NotFound} />
      </Switch>
    </SchoolDashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard/*"} component={DashboardRouter} />
      <Route path={"/students/*"} component={DashboardRouter} />
      <Route path={"/teachers/*"} component={DashboardRouter} />
      <Route path={"/classes/*"} component={DashboardRouter} />
      <Route path={"/attendance/*"} component={DashboardRouter} />
      <Route path={"/academics/*"} component={DashboardRouter} />
      <Route path={"/finance/*"} component={DashboardRouter} />
      <Route path={"/library/*"} component={DashboardRouter} />
      <Route path={"/timetable/*"} component={DashboardRouter} />
      <Route path={"/announcements/*"} component={DashboardRouter} />
      <Route path={"/reports/*"} component={DashboardRouter} />
      <Route path={"/settings/*"} component={DashboardRouter} />
      <Route path={"/scert-books/*"} component={DashboardRouter} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
