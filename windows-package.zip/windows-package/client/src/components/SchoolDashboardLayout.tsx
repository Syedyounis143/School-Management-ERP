import React, { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Menu, X, LogOut, Home, Users, BookOpen, Calendar, FileText, Settings, Bell } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  children?: Omit<NavItem, 'children'>[];
}

const navItems: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: <Home size={20} /> },
  {
    label: 'Students',
    href: '/students',
    icon: <Users size={20} />,
    children: [
      { label: 'Student List', href: '/students', icon: <Users size={16} /> },
      { label: 'Add Student', href: '/students/add', icon: <Users size={16} /> },
      { label: 'Student Records', href: '/students/records', icon: <Users size={16} /> },
    ],
  },
  {
    label: 'Teachers',
    href: '/teachers',
    icon: <Users size={20} />,
    children: [
      { label: 'Teacher List', href: '/teachers', icon: <Users size={16} /> },
      { label: 'Add Teacher', href: '/teachers/add', icon: <Users size={16} /> },
    ],
  },
  {
    label: 'Classes',
    href: '/classes',
    icon: <BookOpen size={20} />,
    children: [
      { label: 'Class List', href: '/classes', icon: <BookOpen size={16} /> },
      { label: 'Add Class', href: '/classes/add', icon: <BookOpen size={16} /> },
      { label: 'Sections', href: '/classes/sections', icon: <BookOpen size={16} /> },
    ],
  },
  {
    label: 'Attendance',
    href: '/attendance',
    icon: <Calendar size={20} />,
    children: [
      { label: 'Mark Attendance', href: '/attendance/mark', icon: <Calendar size={16} /> },
      { label: 'Attendance Reports', href: '/attendance/reports', icon: <Calendar size={16} /> },
    ],
  },
  {
    label: 'Academics',
    href: '/academics',
    icon: <FileText size={20} />,
    children: [
      { label: 'Exams', href: '/academics/exams', icon: <FileText size={16} /> },
      { label: 'Marks Entry', href: '/academics/marks', icon: <FileText size={16} /> },
      { label: 'Report Cards', href: '/academics/report-cards', icon: <FileText size={16} /> },
      { label: 'Performance', href: '/academics/performance', icon: <FileText size={16} /> },
    ],
  },
  {
    label: 'Finance',
    href: '/finance',
    icon: <FileText size={20} />,
    children: [
      { label: 'Fee Structure', href: '/finance/fee-structure', icon: <FileText size={16} /> },
      { label: 'Fee Payments', href: '/finance/payments', icon: <FileText size={16} /> },
      { label: 'Receipts', href: '/finance/receipts', icon: <FileText size={16} /> },
    ],
  },
  {
    label: 'Library',
    href: '/library',
    icon: <BookOpen size={20} />,
    children: [
      { label: 'Book Catalog', href: '/library/books', icon: <BookOpen size={16} /> },
      { label: 'Issue/Return', href: '/library/transactions', icon: <BookOpen size={16} /> },
    ],
  },
  {
    label: 'Timetable',
    href: '/timetable',
    icon: <Calendar size={20} />,
  },
  {
    label: 'Announcements',
    href: '/announcements',
    icon: <Bell size={20} />,
    children: [
      { label: 'View All', href: '/announcements', icon: <Bell size={16} /> },
      { label: 'Create', href: '/announcements/create', icon: <Bell size={16} /> },
      { label: 'Events', href: '/announcements/events', icon: <Bell size={16} /> },
    ],
  },
  {
    label: 'Reports',
    href: '/reports',
    icon: <FileText size={20} />,
    children: [
      { label: 'Student Performance', href: '/reports/performance', icon: <FileText size={16} /> },
      { label: 'Attendance Summary', href: '/reports/attendance', icon: <FileText size={16} /> },
      { label: 'Financial', href: '/reports/financial', icon: <FileText size={16} /> },
    ],
  },
  {
    label: 'Settings',
    href: '/settings',
    icon: <Settings size={20} />,
  },
  {
    label: 'SCERT Books',
    href: '/scert-books',
    icon: <BookOpen size={20} />,
    children: [
      { label: 'Book List', href: '/scert-books', icon: <BookOpen size={16} /> },
      { label: 'Upload Book', href: '/scert-books/upload', icon: <BookOpen size={16} /> },
      { label: 'Question Papers', href: '/scert-books/question-papers', icon: <FileText size={16} /> },
    ],
  },
];

interface SchoolDashboardLayoutProps {
  children: React.ReactNode;
}

export default function SchoolDashboardLayout({ children }: SchoolDashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null);
  const [location, navigate] = useLocation();
  const { user, logout } = useAuth();
  const logoutMutation = trpc.auth.logout.useMutation();

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      toast.success('Logged out successfully');
      navigate('/');
    } catch (error) {
      toast.error('Failed to logout');
    }
  };

  const toggleMenu = (label: string) => {
    setExpandedMenu(expandedMenu === label ? null : label);
  };

  const isActive = (href: string) => location === href || location.startsWith(href + '/');

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? 'w-64' : 'w-0'
        } bg-card border-r border-border transition-all duration-300 ease-in-out overflow-hidden flex flex-col`}
      >
        {/* Logo/Header */}
        <div className="p-6 border-b border-border">
          <h1 className="text-2xl font-bold gradient-text">SchoolMS</h1>
          <p className="text-xs text-muted-foreground mt-1">Management System</p>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-2">
          {navItems.map((item) => (
            <div key={item.label}>
              <button
                onClick={() => {
                  if (item.children) {
                    toggleMenu(item.label);
                  } else {
                    navigate(item.href);
                  }
                }}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg transition-colors duration-200 ${
                  isActive(item.href)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-foreground hover:bg-muted'
                }`}
              >
                {item.icon}
                <span className="flex-1 text-left text-sm font-medium">{item.label}</span>
                {item.children && (
                  <span className={`transition-transform ${expandedMenu === item.label ? 'rotate-180' : ''}`}>
                    ▼
                  </span>
                )}
              </button>

              {/* Submenu */}
              {item.children && expandedMenu === item.label && (
                <div className="mt-1 space-y-1 pl-4">
                  {item.children.map((child) => (
                    <button
                      key={child.label}
                      onClick={() => navigate(child.href)}
                      className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-sm transition-colors duration-200 ${
                        isActive(child.href)
                          ? 'bg-accent text-accent-foreground'
                          : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                      }`}
                    >
                      {child.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* User Profile & Logout */}
        <div className="p-4 border-t border-border space-y-3">
          <div className="px-4 py-3 bg-muted rounded-lg">
            <p className="text-xs text-muted-foreground">Logged in as</p>
            <p className="text-sm font-semibold text-foreground truncate">{user?.name || 'User'}</p>
            <p className="text-xs text-muted-foreground capitalize">{user?.role}</p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="w-full justify-center gap-2"
            disabled={logoutMutation.isPending}
          >
            <LogOut size={16} />
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
          >
            {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-muted rounded-lg transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full"></span>
            </button>
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-white font-bold">
              {user?.name?.charAt(0) || 'U'}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto bg-background">
          <div className="p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
