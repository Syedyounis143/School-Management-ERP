import React from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Users, BookOpen, TrendingUp, AlertCircle } from 'lucide-react';

const Dashboard = () => {
  const studentData = [
    { month: 'Jan', students: 120, teachers: 25, classes: 8 },
    { month: 'Feb', students: 132, teachers: 25, classes: 8 },
    { month: 'Mar', students: 145, teachers: 28, classes: 9 },
    { month: 'Apr', students: 155, teachers: 28, classes: 9 },
    { month: 'May', students: 168, teachers: 30, classes: 10 },
    { month: 'Jun', students: 175, teachers: 30, classes: 10 },
  ];

  const attendanceData = [
    { name: 'Present', value: 85, fill: '#10b981' },
    { name: 'Absent', value: 10, fill: '#ef4444' },
    { name: 'Late', value: 5, fill: '#f59e0b' },
  ];

  return (
    <div className="space-elegant">
      <div className="section-header">
        <h1 className="text-4xl font-bold gradient-text">Dashboard</h1>
        <p className="text-muted mt-2">Welcome to School Management System</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Total Students</p>
              <p className="stat-value">1,245</p>
            </div>
            <Users className="text-primary/20" size={40} />
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Total Teachers</p>
              <p className="stat-value">85</p>
            </div>
            <Users className="text-accent/20" size={40} />
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Active Classes</p>
              <p className="stat-value">42</p>
            </div>
            <BookOpen className="text-primary/20" size={40} />
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="stat-label">Attendance Rate</p>
              <p className="stat-value">92%</p>
            </div>
            <TrendingUp className="text-accent/20" size={40} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card-elegant p-6">
          <h3 className="text-lg font-semibold mb-4">Enrollment Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={studentData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis stroke="var(--muted-foreground)" />
              <YAxis stroke="var(--muted-foreground)" />
              <Tooltip contentStyle={{ backgroundColor: 'var(--card)', border: '1px solid var(--border)' }} />
              <Legend />
              <Line type="monotone" dataKey="students" stroke="var(--primary)" strokeWidth={2} />
              <Line type="monotone" dataKey="teachers" stroke="var(--accent)" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="card-elegant p-6">
          <h3 className="text-lg font-semibold mb-4">Today's Attendance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={attendanceData} cx="50%" cy="50%" labelLine={false} label={({ name, value }) => `${name}: ${value}%`} outerRadius={80} fill="#8884d8" dataKey="value">
                {attendanceData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card-elegant p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Announcements</h3>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-3 bg-muted rounded-lg">
                <p className="font-medium text-sm">Announcement {i}</p>
                <p className="text-xs text-muted-foreground mt-1">Posted 2 hours ago</p>
              </div>
            ))}
          </div>
        </div>

        <div className="card-elegant p-6">
          <h3 className="text-lg font-semibold mb-4">Upcoming Events</h3>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-3 bg-muted rounded-lg">
                <p className="font-medium text-sm">Event {i}</p>
                <p className="text-xs text-muted-foreground mt-1">Scheduled for tomorrow</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card-elegant p-6 border-l-4 border-l-destructive bg-destructive/5">
        <div className="flex items-start gap-4">
          <AlertCircle className="text-destructive mt-1" size={24} />
          <div>
            <h4 className="font-semibold">Pending Tasks</h4>
            <p className="text-sm text-muted-foreground mt-1">You have 5 pending fee payments to follow up on.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
