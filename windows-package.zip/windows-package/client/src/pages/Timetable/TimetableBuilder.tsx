import React, { useState } from 'react';
import { Plus, Edit, Save, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { useLocation } from 'wouter';

const TimetableBuilder = () => {
  const [selectedClass, setSelectedClass] = useState('');
  const [, navigate] = useLocation();

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const periods = ['Period 1', 'Period 2', 'Period 3', 'Break', 'Period 4', 'Period 5', 'Period 6'];

  const timetable = {
    'Class 10-A': {
      Monday: ['Mathematics', 'English', 'Science', 'Break', 'Social Studies', 'Hindi', 'PE'],
      Tuesday: ['English', 'Mathematics', 'History', 'Break', 'Science', 'Geography', 'Art'],
      Wednesday: ['Science', 'Hindi', 'Mathematics', 'Break', 'English', 'Social Studies', 'Computer'],
      Thursday: ['Social Studies', 'Science', 'English', 'Break', 'Mathematics', 'Hindi', 'Music'],
      Friday: ['Mathematics', 'Science', 'Social Studies', 'Break', 'English', 'Computer', 'PE'],
    }
  };

  const handleSaveTimetable = () => {
    toast.success('Timetable saved successfully');
  };

  const handleEditPeriod = (day: string, period: number) => {
    toast.info('Edit period functionality coming soon');
  };

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">Timetable Management</h1>
          <p className="text-muted mt-2">Create and manage class schedules</p>
        </div>
        <Button onClick={handleSaveTimetable} className="gap-2">
          <Save size={20} />
          Save Timetable
        </Button>
      </div>

      <div className="card-elegant p-6">
        <div className="mb-6">
          <Label>Select Class</Label>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="input-elegant mt-2"
          >
            <option value="">Choose a class...</option>
            <option value="Class 10-A">Class 10-A</option>
            <option value="Class 10-B">Class 10-B</option>
            <option value="Class 9-A">Class 9-A</option>
            <option value="Class 9-B">Class 9-B</option>
          </select>
        </div>

        {selectedClass && (
          <div className="overflow-x-auto">
            <table className="w-full border border-border rounded-lg overflow-hidden">
              <thead className="bg-muted border-b border-border">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Period</th>
                  {days.map((day) => (
                    <th key={day} className="px-4 py-3 text-left text-sm font-semibold">{day}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {periods.map((period, idx) => (
                  <tr key={idx} className="hover:bg-muted/50 transition-colors">
                    <td className="px-4 py-3 font-medium text-sm bg-muted">{period}</td>
                    {days.map((day) => (
                      <td key={`${day}-${idx}`} className="px-4 py-3">
                        {period === 'Break' ? (
                          <span className="text-muted-foreground text-sm">Break</span>
                        ) : (
                          <button
                            onClick={() => handleEditPeriod(day, idx)}
                            className="text-sm font-medium text-primary hover:underline"
                          >
                            {timetable[selectedClass as keyof typeof timetable]?.[day as keyof typeof timetable['Class 10-A']]?.[idx] || 'Add Subject'}
                          </button>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {!selectedClass && (
          <div className="text-center py-12 text-muted">
            <Calendar size={48} className="mx-auto mb-4 opacity-50" />
            <p>Select a class to view or edit the timetable</p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div className="stat-card">
          <p className="stat-label">Classes</p>
          <p className="stat-value">4</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Total Periods</p>
          <p className="stat-value">35</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Teachers Assigned</p>
          <p className="stat-value">12</p>
        </div>
      </div>
    </div>
  );
};

export default TimetableBuilder;
