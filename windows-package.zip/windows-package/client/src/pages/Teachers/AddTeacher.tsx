import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';
import { ArrowLeft } from 'lucide-react';

const AddTeacher = () => {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    employeeId: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    gender: '' as 'male' | 'female' | 'other' | '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    qualification: '',
    experience: '',
    joiningDate: new Date().toISOString().split('T')[0],
  });

  const createMutation = trpc.teachers.create.useMutation();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === 'gender') {
      setFormData(prev => ({ ...prev, [name]: value as 'male' | 'female' | 'other' | '' }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const submitData = {
        employeeId: formData.employeeId,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        dateOfBirth: formData.dateOfBirth || undefined,
        gender: (formData.gender as 'male' | 'female' | 'other' | undefined) || undefined,
        address: formData.address || undefined,
        city: formData.city || undefined,
        state: formData.state || undefined,
        zipCode: formData.zipCode || undefined,
        qualification: formData.qualification || undefined,
        experience: formData.experience ? parseInt(formData.experience) : undefined,
        joiningDate: formData.joiningDate,
      };
      await createMutation.mutateAsync(submitData);
      toast.success('Teacher added successfully');
      navigate('/teachers');
    } catch (error) {
      toast.error('Failed to add teacher');
    }
  };

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center gap-4">
        <button onClick={() => navigate('/teachers')} className="p-2 hover:bg-muted rounded-lg">
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-4xl font-bold gradient-text">Add Teacher</h1>
          <p className="text-muted mt-2">Enter teacher information</p>
        </div>
      </div>

      <div className="card-elegant p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Basic Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <Label>Employee ID *</Label>
                <Input name="employeeId" value={formData.employeeId} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <Label>First Name *</Label>
                <Input name="firstName" value={formData.firstName} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <Label>Last Name *</Label>
                <Input name="lastName" value={formData.lastName} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <Label>Date of Birth</Label>
                <Input type="date" name="dateOfBirth" value={formData.dateOfBirth} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>Gender</Label>
                <select name="gender" value={formData.gender || ''} onChange={handleChange} className="input-elegant">
                  <option value="">Select Gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div className="form-group">
                <Label>Joining Date *</Label>
                <Input type="date" name="joiningDate" value={formData.joiningDate} onChange={handleChange} required />
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <Label>Email *</Label>
                <Input type="email" name="email" value={formData.email} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <Label>Phone *</Label>
                <Input name="phone" value={formData.phone} onChange={handleChange} required />
              </div>
              <div className="form-group md:col-span-2">
                <Label>Address</Label>
                <Textarea name="address" value={formData.address} onChange={handleChange} rows={3} />
              </div>
              <div className="form-group">
                <Label>City</Label>
                <Input name="city" value={formData.city} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>State</Label>
                <Input name="state" value={formData.state} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>Zip Code</Label>
                <Input name="zipCode" value={formData.zipCode} onChange={handleChange} />
              </div>
            </div>
          </div>

          {/* Professional Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Professional Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <Label>Qualification</Label>
                <Input name="qualification" value={formData.qualification} onChange={handleChange} placeholder="e.g., B.Tech, M.Sc" />
              </div>
              <div className="form-group">
                <Label>Experience (Years)</Label>
                <Input type="number" name="experience" value={formData.experience} onChange={handleChange} />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex gap-4 pt-6 border-t border-border">
            <Button type="submit" disabled={createMutation.isPending}>
              {createMutation.isPending ? 'Adding...' : 'Add Teacher'}
            </Button>
            <Button type="button" variant="outline" onClick={() => navigate('/teachers')}>
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddTeacher;
