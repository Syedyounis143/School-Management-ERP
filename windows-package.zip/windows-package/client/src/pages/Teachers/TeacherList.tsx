import React, { useState } from 'react';
import { Search, Plus, Eye, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

const TeacherList = () => {
  const [search, setSearch] = useState('');
  const [, navigate] = useLocation();
  const { data: teachers = [], isLoading } = trpc.teachers.list.useQuery({ search: search || undefined });

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">Teachers</h1>
          <p className="text-muted mt-2">Manage teacher profiles and assignments</p>
        </div>
        <Button onClick={() => navigate('/teachers/add')} className="gap-2">
          <Plus size={20} />
          Add Teacher
        </Button>
      </div>

      {/* Search Bar */}
      <div className="card-elegant p-4">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
            <Input
              placeholder="Search by name, employee ID, email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </div>

      {/* Teachers Table */}
      <div className="card-elegant overflow-hidden">
        <table className="table-elegant">
          <thead>
            <tr>
              <th>Employee ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Qualification</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={7} className="text-center py-8 text-muted">
                  Loading teachers...
                </td>
              </tr>
            ) : teachers.length === 0 ? (
              <tr>
                <td colSpan={7} className="text-center py-8 text-muted">
                  No teachers found
                </td>
              </tr>
            ) : (
              teachers.map((teacher) => (
                <tr key={teacher.id}>
                  <td className="font-medium">{teacher.employeeId}</td>
                  <td>{`${teacher.firstName} ${teacher.lastName}`}</td>
                  <td className="text-muted">{teacher.email}</td>
                  <td>{teacher.phone}</td>
                  <td className="text-muted text-sm">{teacher.qualification || '-'}</td>
                  <td>
                    <span className={`status-${teacher.status}`}>
                      {teacher.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-2">
                      <button className="p-1 hover:bg-muted rounded transition-colors">
                        <Eye size={16} className="text-muted-foreground" />
                      </button>
                      <button className="p-1 hover:bg-muted rounded transition-colors">
                        <Edit size={16} className="text-muted-foreground" />
                      </button>
                      <button className="p-1 hover:bg-muted rounded transition-colors">
                        <Trash2 size={16} className="text-destructive" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination info */}
      <div className="text-sm text-muted-foreground">
        Showing {teachers.length} teacher{teachers.length !== 1 ? 's' : ''}
      </div>
    </div>
  );
};

export default TeacherList;
