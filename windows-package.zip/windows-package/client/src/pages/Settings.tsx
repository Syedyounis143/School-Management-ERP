import React from 'react';
import { Settings as SettingsIcon } from 'lucide-react';

const Settings = () => {
  return (
    <div className="space-elegant">
      <div className="section-header">
        <h1 className="text-4xl font-bold gradient-text">Settings</h1>
        <p className="text-muted mt-2">Manage system configuration</p>
      </div>
      <div className="card-elegant p-6">
        <p className="text-muted">Settings page coming soon...</p>
      </div>
    </div>
  );
};

export default Settings;
