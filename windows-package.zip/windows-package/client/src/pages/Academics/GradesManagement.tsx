import React, { useState } from 'react';
import { Plus, Search, Edit, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

const GradesManagement = () => {
  const [search, setSearch] = useState('');
  const [selectedExam, setSelectedExam] = useState('');
  const [selectedClass, setSelectedClass] = useState('');
  const [, navigate] = useLocation();

  const { data: classes = [] } = trpc.classes.list.useQuery();
  const { data: students = [] } = trpc.students.list.useQuery({ search });

  const handleGenerateReportCard = (studentId: number) => {
    toast.info('Generating report card...');
  };

  const handleExportGrades = () => {
    toast.info('Exporting grades to CSV...');
  };

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">Grades & Results</h1>
          <p className="text-muted mt-2">Manage student grades and academic performance</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => navigate('/academics/marks')} className="gap-2">
            <Edit size={20} />
            Enter Marks
          </Button>
          <Button onClick={handleExportGrades} variant="outline" className="gap-2">
            <Download size={20} />
            Export
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="card-elegant p-4">
          <Label>Select Class</Label>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="input-elegant mt-2"
          >
            <option value="">All Classes</option>
            {classes.map((cls: any) => (
              <option key={cls.id} value={cls.id}>{cls.name}</option>
            ))}
          </select>
        </div>

        <div className="card-elegant p-4">
          <Label>Search Student</Label>
          <div className="relative mt-2">
            <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
            <Input
              placeholder="Search..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="card-elegant p-4">
          <Label>Select Exam</Label>
          <select
            value={selectedExam}
            onChange={(e) => setSelectedExam(e.target.value)}
            className="input-elegant mt-2"
          >
            <option value="">All Exams</option>
            <option value="midterm">Mid-Term</option>
            <option value="final">Final</option>
            <option value="unit">Unit Test</option>
          </select>
        </div>
      </div>

      <div className="card-elegant overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted border-b border-border">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold">Student Name</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Roll No</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Class</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Total Marks</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Grade</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {students.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-muted">No students found</td>
                </tr>
              ) : (
                students.map((student: any) => (
                  <tr key={student.id} className="hover:bg-muted/50 transition-colors">
                    <td className="px-6 py-3 font-medium">{student.firstName} {student.lastName}</td>
                    <td className="px-6 py-3">{student.rollNumber}</td>
                    <td className="px-6 py-3">Class {student.classId}</td>
                    <td className="px-6 py-3">85/100</td>
                    <td className="px-6 py-3">
                      <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium">A</span>
                    </td>
                    <td className="px-6 py-3">
                      <button onClick={() => handleGenerateReportCard(student.id)} className="text-primary hover:underline text-sm">
                        View Report Card
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
        <div className="stat-card">
          <p className="stat-label">Total Students</p>
          <p className="stat-value">{students.length}</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Avg Score</p>
          <p className="stat-value">82.5</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Pass Rate</p>
          <p className="stat-value">95%</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Exams</p>
          <p className="stat-value">3</p>
        </div>
      </div>
    </div>
  );
};

export default GradesManagement;
