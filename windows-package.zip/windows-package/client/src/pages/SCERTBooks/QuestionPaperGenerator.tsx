import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';
import { ArrowLeft, Plus, Trash2 } from 'lucide-react';

const QuestionPaperGenerator = () => {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    title: '',
    classLevel: '',
    subject: '',
    totalMarks: '',
    totalTime: '',
    templateName: '',
  });
  const [sections, setSections] = useState([
    { name: 'Section A', marks: '20', questionCount: '5', difficulty: 'easy' },
  ]);

  const createMutation = trpc.questionPapers.create.useMutation();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSectionChange = (index: number, field: string, value: string) => {
    const newSections = [...sections];
    newSections[index] = { ...newSections[index], [field]: value };
    setSections(newSections);
  };

  const addSection = () => {
    setSections([...sections, { name: `Section ${String.fromCharCode(65 + sections.length)}`, marks: '20', questionCount: '5', difficulty: 'medium' }]);
  };

  const removeSection = (index: number) => {
    setSections(sections.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createMutation.mutateAsync({
        ...formData,
        totalMarks: parseFloat(formData.totalMarks),
        totalTime: formData.totalTime ? parseInt(formData.totalTime) : undefined,
        status: 'draft',
      });
      toast.success('Question paper created successfully');
      navigate('/scert-books');
    } catch (error) {
      toast.error('Failed to create question paper');
    }
  };

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center gap-4">
        <button onClick={() => navigate('/scert-books')} className="p-2 hover:bg-muted rounded-lg">
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-4xl font-bold gradient-text">Generate Question Paper</h1>
          <p className="text-muted mt-2">Create a new question paper from SCERT books</p>
        </div>
      </div>

      <div className="card-elegant p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold mb-4">Question Paper Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <Label>Title *</Label>
                <Input name="title" value={formData.title} onChange={handleChange} placeholder="e.g., Mid-Term Exam 2024" required />
              </div>
              <div className="form-group">
                <Label>Class Level *</Label>
                <Input name="classLevel" value={formData.classLevel} onChange={handleChange} placeholder="e.g., Class 10" required />
              </div>
              <div className="form-group">
                <Label>Subject *</Label>
                <Input name="subject" value={formData.subject} onChange={handleChange} placeholder="e.g., Mathematics" required />
              </div>
              <div className="form-group">
                <Label>Total Marks *</Label>
                <Input type="number" name="totalMarks" value={formData.totalMarks} onChange={handleChange} placeholder="e.g., 100" required />
              </div>
              <div className="form-group">
                <Label>Total Time (minutes)</Label>
                <Input type="number" name="totalTime" value={formData.totalTime} onChange={handleChange} placeholder="e.g., 180" />
              </div>
              <div className="form-group">
                <Label>Template Name</Label>
                <Input name="templateName" value={formData.templateName} onChange={handleChange} placeholder="Save as template" />
              </div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Question Sections</h3>
              <Button type="button" onClick={addSection} variant="outline" size="sm" className="gap-2">
                <Plus size={16} />
                Add Section
              </Button>
            </div>

            <div className="space-y-4">
              {sections.map((section, index) => (
                <div key={index} className="p-4 border border-border rounded-lg">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-2">
                    <div className="form-group">
                      <Label>Section Name</Label>
                      <Input
                        value={section.name}
                        onChange={(e) => handleSectionChange(index, 'name', e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <Label>Marks</Label>
                      <Input
                        type="number"
                        value={section.marks}
                        onChange={(e) => handleSectionChange(index, 'marks', e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <Label>Question Count</Label>
                      <Input
                        type="number"
                        value={section.questionCount}
                        onChange={(e) => handleSectionChange(index, 'questionCount', e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <Label>Difficulty</Label>
                      <select
                        value={section.difficulty}
                        onChange={(e) => handleSectionChange(index, 'difficulty', e.target.value)}
                        className="input-elegant"
                      >
                        <option value="easy">Easy</option>
                        <option value="medium">Medium</option>
                        <option value="hard">Hard</option>
                      </select>
                    </div>
                  </div>
                  {sections.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeSection(index)}
                      className="text-destructive text-sm flex items-center gap-1 hover:underline"
                    >
                      <Trash2 size={14} />
                      Remove Section
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-4 pt-6 border-t border-border">
            <Button type="submit" disabled={createMutation.isPending}>
              {createMutation.isPending ? 'Generating...' : 'Generate Question Paper'}
            </Button>
            <Button type="button" variant="outline" onClick={() => navigate('/scert-books')}>
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default QuestionPaperGenerator;
