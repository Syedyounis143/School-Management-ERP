import React, { useState } from 'react';
import { Search, Plus, Upload, Eye, Edit, Trash2, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

const BookList = () => {
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('');
  const [, navigate] = useLocation();
  const { data: books = [], isLoading } = trpc.scertBooks.list.useQuery({ 
    classLevel: classFilter || undefined,
    subject: subjectFilter || undefined,
    search: search || undefined 
  });

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">SCERT Telangana Books</h1>
          <p className="text-muted mt-2">Manage textbooks and learning materials</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => navigate('/scert-books/upload')} className="gap-2">
            <Upload size={20} />
            Upload Book
          </Button>
          <Button onClick={() => navigate('/scert-books/question-papers')} variant="outline" className="gap-2">
            <Plus size={20} />
            Create Question Paper
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="card-elegant p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
            <Input
              placeholder="Search books..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
          <Input
            placeholder="Filter by class..."
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
          />
          <Input
            placeholder="Filter by subject..."
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
          />
        </div>
      </div>

      {/* Books Table */}
      <div className="card-elegant overflow-hidden">
        <table className="table-elegant">
          <thead>
            <tr>
              <th>Title</th>
              <th>Author</th>
              <th>Class</th>
              <th>Subject</th>
              <th>Pages</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={7} className="text-center py-8 text-muted">
                  Loading books...
                </td>
              </tr>
            ) : books.length === 0 ? (
              <tr>
                <td colSpan={7} className="text-center py-8 text-muted">
                  No books found
                </td>
              </tr>
            ) : (
              books.map((book: any) => (
                <tr key={book.id}>
                  <td className="font-medium">{book.title}</td>
                  <td>{book.author}</td>
                  <td>{book.classLevel}</td>
                  <td>{book.subject}</td>
                  <td>{book.totalPages || '-'}</td>
                  <td>
                    <span className={`status-${book.status}`}>
                      {book.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-2">
                      <button className="p-1 hover:bg-muted rounded transition-colors" title="View">
                        <Eye size={16} className="text-muted-foreground" />
                      </button>
                      <button className="p-1 hover:bg-muted rounded transition-colors" title="Edit">
                        <Edit size={16} className="text-muted-foreground" />
                      </button>
                      <button className="p-1 hover:bg-muted rounded transition-colors" title="Download">
                        <Download size={16} className="text-muted-foreground" />
                      </button>
                      <button className="p-1 hover:bg-muted rounded transition-colors" title="Delete">
                        <Trash2 size={16} className="text-destructive" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="stat-card">
          <p className="stat-label">Total Books</p>
          <p className="stat-value">{books.length}</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Active Books</p>
          <p className="stat-value">{books.filter((b: any) => b.status === 'active').length}</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Subjects</p>
          <p className="stat-value">{new Set(books.map((b: any) => b.subject)).size}</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Classes</p>
          <p className="stat-value">{new Set(books.map((b: any) => b.classLevel)).size}</p>
        </div>
      </div>
    </div>
  );
};

export default BookList;
