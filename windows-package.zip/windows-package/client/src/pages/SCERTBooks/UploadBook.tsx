import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';
import { ArrowLeft, Upload } from 'lucide-react';

const UploadBook = () => {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    publisher: '',
    isbn: '',
    classLevel: '',
    subject: '',
    description: '',
    totalPages: '',
  });
  const [file, setFile] = useState<File | null>(null);

  const createMutation = trpc.scertBooks.create.useMutation();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      toast.error('Please select a PDF file');
      return;
    }

    try {
      await createMutation.mutateAsync({
        ...formData,
        totalPages: formData.totalPages ? parseInt(formData.totalPages) : undefined,
        fileUrl: `https://example.com/books/${file.name}`,
        filePath: file.name,
        fileSize: file.size,
        status: 'active',
      })
      toast.success('Book uploaded successfully');
      navigate('/scert-books');
    } catch (error) {
      toast.error('Failed to upload book');
    }
  };

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center gap-4">
        <button onClick={() => navigate('/scert-books')} className="p-2 hover:bg-muted rounded-lg">
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-4xl font-bold gradient-text">Upload SCERT Book</h1>
          <p className="text-muted mt-2">Add a new textbook to the system</p>
        </div>
      </div>

      <div className="card-elegant p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold mb-4">Book Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <Label>Title *</Label>
                <Input name="title" value={formData.title} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <Label>Author *</Label>
                <Input name="author" value={formData.author} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <Label>Publisher</Label>
                <Input name="publisher" value={formData.publisher} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>ISBN</Label>
                <Input name="isbn" value={formData.isbn} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>Class Level *</Label>
                <Input name="classLevel" value={formData.classLevel} onChange={handleChange} placeholder="e.g., Class 10" required />
              </div>
              <div className="form-group">
                <Label>Subject *</Label>
                <Input name="subject" value={formData.subject} onChange={handleChange} placeholder="e.g., Mathematics" required />
              </div>
              <div className="form-group">
                <Label>Total Pages</Label>
                <Input type="number" name="totalPages" value={formData.totalPages} onChange={handleChange} />
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Upload PDF</h3>
            <div className="form-group">
              <Label>PDF File *</Label>
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:bg-muted/50 transition-colors cursor-pointer">
                <input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileChange}
                  className="hidden"
                  id="pdf-upload"
                  required
                />
                <label htmlFor="pdf-upload" className="cursor-pointer flex flex-col items-center gap-2">
                  <Upload size={40} className="text-muted-foreground" />
                  <span className="font-medium">
                    {file ? file.name : 'Click to upload or drag and drop'}
                  </span>
                  <span className="text-sm text-muted-foreground">PDF files only (Max 100MB)</span>
                </label>
              </div>
            </div>
          </div>

          <div className="flex gap-4 pt-6 border-t border-border">
            <Button type="submit" disabled={createMutation.isPending}>
              {createMutation.isPending ? 'Uploading...' : 'Upload Book'}
            </Button>
            <Button type="button" variant="outline" onClick={() => navigate('/scert-books')}>
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UploadBook;
