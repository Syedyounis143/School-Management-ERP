import React, { useState } from 'react';
import { Plus, Search, Download, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

const FeeManagementDashboard = () => {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [, navigate] = useLocation();

  const { data: students = [] } = trpc.students.list.useQuery({ search });

  const handleSendReminder = (studentId: number) => {
    toast.success('Payment reminder sent');
  };

  const handleGenerateReceipt = (studentId: number) => {
    toast.info('Generating receipt...');
  };

  const feeData = [
    { studentId: 1, name: 'Aarav Kumar', class: '10-A', totalFee: 50000, paid: 50000, status: 'paid', dueDate: '2024-03-15' },
    { studentId: 2, name: 'Priya Sharma', class: '10-B', totalFee: 50000, paid: 25000, status: 'pending', dueDate: '2024-02-28' },
    { studentId: 3, name: 'Rohan Patel', class: '10-A', totalFee: 50000, paid: 0, status: 'overdue', dueDate: '2024-02-15' },
  ];

  const filteredData = feeData.filter(fee => {
    if (filterStatus === 'all') return true;
    return fee.status === filterStatus;
  });

  const totalCollected = feeData.reduce((sum, f) => sum + f.paid, 0);
  const totalDue = feeData.reduce((sum, f) => sum + (f.totalFee - f.paid), 0);
  const collectionRate = Math.round((totalCollected / (totalCollected + totalDue)) * 100);

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">Fee Management</h1>
          <p className="text-muted mt-2">Track and manage student fee payments</p>
        </div>
        <Button onClick={() => navigate('/finance/fee-structure')} className="gap-2">
          <Plus size={20} />
          New Payment
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="stat-card">
          <p className="stat-label">Total Collected</p>
          <p className="stat-value">₹{(totalCollected / 100000).toFixed(1)}L</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Total Due</p>
          <p className="stat-value">₹{(totalDue / 100000).toFixed(1)}L</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Collection Rate</p>
          <p className="stat-value">{collectionRate}%</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Total Students</p>
          <p className="stat-value">{feeData.length}</p>
        </div>
      </div>

      <div className="card-elegant p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="form-group">
            <Label>Search Student</Label>
            <div className="relative">
              <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
              <Input
                placeholder="Search..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="form-group">
            <Label>Filter by Status</Label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="input-elegant"
            >
              <option value="all">All</option>
              <option value="paid">Paid</option>
              <option value="pending">Pending</option>
              <option value="overdue">Overdue</option>
            </select>
          </div>

          <div className="flex items-end">
            <Button variant="outline" className="w-full gap-2">
              <Download size={20} />
              Export Report
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted border-b border-border">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold">Student Name</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Class</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Total Fee</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Paid</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Due</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Status</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filteredData.map((fee) => (
                <tr key={fee.studentId} className="hover:bg-muted/50 transition-colors">
                  <td className="px-6 py-3 font-medium">{fee.name}</td>
                  <td className="px-6 py-3">{fee.class}</td>
                  <td className="px-6 py-3">₹{fee.totalFee.toLocaleString()}</td>
                  <td className="px-6 py-3 text-emerald-600 font-medium">₹{fee.paid.toLocaleString()}</td>
                  <td className="px-6 py-3 text-destructive font-medium">₹{(fee.totalFee - fee.paid).toLocaleString()}</td>
                  <td className="px-6 py-3">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      fee.status === 'paid' ? 'bg-emerald-100 text-emerald-700' :
                      fee.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                      'bg-destructive/10 text-destructive'
                    }`}>
                      {fee.status.charAt(0).toUpperCase() + fee.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-3">
                    <div className="flex gap-2">
                      <button onClick={() => handleGenerateReceipt(fee.studentId)} className="text-primary text-sm hover:underline">
                        Receipt
                      </button>
                      {fee.status !== 'paid' && (
                        <button onClick={() => handleSendReminder(fee.studentId)} className="text-amber-600 text-sm hover:underline">
                          Remind
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FeeManagementDashboard;
