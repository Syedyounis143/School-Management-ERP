import React, { useState } from 'react';
import { Plus, Bell, Calendar, Users, Trash2, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { useLocation } from 'wouter';

const AnnouncementsHub = () => {
  const [activeTab, setActiveTab] = useState('announcements');
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ title: '', content: '', date: '', audience: 'all' });
  const [, navigate] = useLocation();

  const announcements = [
    { id: 1, title: 'Mid-Term Exams Scheduled', content: 'Mid-term exams will be conducted from March 15-25, 2024', date: '2024-03-08', author: 'Principal', audience: 'all' },
    { id: 2, title: 'School Sports Day', content: 'Annual sports day on March 20, 2024. All students are encouraged to participate.', date: '2024-03-07', author: 'Sports Coordinator', audience: 'students' },
    { id: 3, title: 'Fee Payment Reminder', content: 'Please ensure fee payment by March 15, 2024', date: '2024-03-06', author: 'Finance', audience: 'parents' },
  ];

  const events = [
    { id: 1, title: 'Annual Day Celebration', date: '2024-04-15', time: '10:00 AM', location: 'School Auditorium', attendees: 450 },
    { id: 2, title: 'Science Fair', date: '2024-03-25', time: '02:00 PM', location: 'School Premises', attendees: 200 },
    { id: 3, title: 'Parent-Teacher Meeting', date: '2024-03-18', time: '03:00 PM', location: 'Classrooms', attendees: 300 },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Announcement posted successfully');
    setShowForm(false);
    setFormData({ title: '', content: '', date: '', audience: 'all' });
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure?')) {
      toast.success('Deleted successfully');
    }
  };

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">Announcements & Events</h1>
          <p className="text-muted mt-2">School-wide communication and event management</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus size={20} />
          New Announcement
        </Button>
      </div>

      {showForm && (
        <div className="card-elegant p-6">
          <h3 className="text-lg font-semibold mb-4">Create New Announcement</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="form-group">
              <Label>Title</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Announcement title"
                required
              />
            </div>

            <div className="form-group">
              <Label>Content</Label>
              <Textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                placeholder="Announcement content"
                rows={4}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <Label>Date</Label>
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                />
              </div>

              <div className="form-group">
                <Label>Audience</Label>
                <select
                  value={formData.audience}
                  onChange={(e) => setFormData({ ...formData, audience: e.target.value })}
                  className="input-elegant"
                >
                  <option value="all">All</option>
                  <option value="students">Students Only</option>
                  <option value="parents">Parents Only</option>
                  <option value="teachers">Teachers Only</option>
                </select>
              </div>
            </div>

            <div className="flex gap-4">
              <Button type="submit">Post Announcement</Button>
              <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </form>
        </div>
      )}

      <div className="flex gap-4 mb-6">
        <button
          onClick={() => setActiveTab('announcements')}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            activeTab === 'announcements'
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted text-foreground hover:bg-muted/80'
          }`}
        >
          <Bell size={16} className="inline mr-2" />
          Announcements
        </button>
        <button
          onClick={() => setActiveTab('events')}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            activeTab === 'events'
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted text-foreground hover:bg-muted/80'
          }`}
        >
          <Calendar size={16} className="inline mr-2" />
          Events
        </button>
      </div>

      {activeTab === 'announcements' && (
        <div className="space-y-4">
          {announcements.map((ann) => (
            <div key={ann.id} className="card-elegant p-6 hover-lift">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-lg font-semibold">{ann.title}</h3>
                  <p className="text-sm text-muted-foreground">{ann.date} • {ann.author}</p>
                </div>
                <div className="flex gap-2">
                  <button className="p-2 hover:bg-muted rounded">
                    <Edit size={16} className="text-muted-foreground" />
                  </button>
                  <button onClick={() => handleDelete(ann.id)} className="p-2 hover:bg-muted rounded">
                    <Trash2 size={16} className="text-destructive" />
                  </button>
                </div>
              </div>
              <p className="text-foreground">{ann.content}</p>
              <div className="mt-3 pt-3 border-t border-border">
                <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                  {ann.audience === 'all' ? 'All Users' : ann.audience.charAt(0).toUpperCase() + ann.audience.slice(1)}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'events' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {events.map((event) => (
            <div key={event.id} className="card-elegant p-6 hover-lift">
              <div className="flex items-start justify-between mb-3">
                <h3 className="text-lg font-semibold">{event.title}</h3>
                <Calendar size={20} className="text-primary" />
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Calendar size={16} />
                  <span>{event.date} at {event.time}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users size={16} />
                  <span>{event.attendees} attendees</span>
                </div>
                <div className="text-muted-foreground">
                  📍 {event.location}
                </div>
              </div>

              <Button variant="outline" size="sm" className="w-full mt-4">
                View Details
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AnnouncementsHub;
