import React, { useState } from 'react';
import { Calendar, Check, X, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

const AttendanceMarkingSystem = () => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedClass, setSelectedClass] = useState('');
  const [attendanceData, setAttendanceData] = useState<Record<number, boolean>>({});
  
  const { data: classes = [] } = trpc.classes.list.useQuery();
  const { data: students = [] } = trpc.students.list.useQuery({ search: '' });

  const handleAttendanceToggle = (studentId: number) => {
    setAttendanceData(prev => ({
      ...prev,
      [studentId]: !prev[studentId]
    }));
  };

  const handleSaveAttendance = async () => {
    if (!selectedClass || !selectedDate) {
      toast.error('Please select class and date');
      return;
    }
    toast.success('Attendance marked successfully');
    setAttendanceData({});
  };

  const presentCount = Object.values(attendanceData).filter(Boolean).length;
  const totalStudents = students.length;
  const filteredStudents = students.filter((s: any) => selectedClass === '' || s.classId === parseInt(selectedClass));

  return (
    <div className="space-elegant">
      <div className="section-header">
        <h1 className="text-4xl font-bold gradient-text">Mark Attendance</h1>
        <p className="text-muted mt-2">Record student attendance for the day</p>
      </div>

      <div className="card-elegant p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="form-group">
            <Label>Select Date</Label>
            <div className="flex items-center gap-2">
              <Calendar size={20} className="text-muted-foreground" />
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
              />
            </div>
          </div>

          <div className="form-group">
            <Label>Select Class</Label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="input-elegant"
            >
              <option value="">Choose a class...</option>
              {classes.map((cls: any) => (
                <option key={cls.id} value={cls.id}>{cls.name}</option>
              ))}
            </select>
          </div>

          <div className="flex items-end">
            <div className="stat-card w-full">
              <p className="stat-label">Present / Total</p>
              <p className="stat-value text-2xl">{presentCount} / {filteredStudents.length}</p>
            </div>
          </div>
        </div>

        {selectedClass && filteredStudents.length > 0 && (
          <>
            <div className="mb-6 p-4 bg-muted rounded-lg">
              <h3 className="font-semibold mb-4">Student Attendance</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-96 overflow-y-auto">
                {filteredStudents.map((student: any) => (
                  <div key={student.id} className="flex items-center gap-3 p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                    <button
                      onClick={() => handleAttendanceToggle(student.id)}
                      className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
                        attendanceData[student.id]
                          ? 'bg-emerald-500 text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {attendanceData[student.id] ? <Check size={20} /> : <X size={20} />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{student.firstName} {student.lastName}</p>
                      <p className="text-xs text-muted-foreground">{student.rollNumber}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-4">
              <Button onClick={handleSaveAttendance} className="gap-2">
                <Save size={20} />
                Save Attendance
              </Button>
              <Button variant="outline" onClick={() => setAttendanceData({})}>
                Clear All
              </Button>
            </div>
          </>
        )}

        {selectedClass && filteredStudents.length === 0 && (
          <div className="text-center py-8 text-muted">
            No students found in this class
          </div>
        )}
      </div>
    </div>
  );
};

export default AttendanceMarkingSystem;
