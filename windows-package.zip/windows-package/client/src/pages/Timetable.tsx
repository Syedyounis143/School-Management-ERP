import React from 'react';
import { Calendar } from 'lucide-react';

const Timetable = () => {
  return (
    <div className="space-elegant">
      <div className="section-header">
        <h1 className="text-4xl font-bold gradient-text">Timetable</h1>
        <p className="text-muted mt-2">Class schedule and period management</p>
      </div>
      <div className="card-elegant p-6">
        <p className="text-muted">Timetable page coming soon...</p>
      </div>
    </div>
  );
};

export default Timetable;
