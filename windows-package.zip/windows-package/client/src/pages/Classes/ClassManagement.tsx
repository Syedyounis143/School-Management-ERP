import React, { useState } from 'react';
import { Search, Plus, Edit, Trash2, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

const ClassManagement = () => {
  const [search, setSearch] = useState('');
  const [, navigate] = useLocation();
  const { data: classes = [], isLoading } = trpc.classes.list.useQuery();
  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to delete this class?')) {
      toast.info('Delete functionality coming soon');
    }
  };

  const filteredClasses = classes.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">Classes & Sections</h1>
          <p className="text-muted mt-2">Manage school classes and sections</p>
        </div>
        <Button onClick={() => navigate('/classes/add')} className="gap-2">
          <Plus size={20} />
          Add Class
        </Button>
      </div>

      <div className="card-elegant p-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
          <Input
            placeholder="Search classes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          <div className="col-span-full text-center py-8 text-muted">Loading classes...</div>
        ) : filteredClasses.length === 0 ? (
          <div className="col-span-full text-center py-8 text-muted">No classes found</div>
        ) : (
          filteredClasses.map((cls: any) => (
            <div key={cls.id} className="card-elegant p-6 hover-lift">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold text-primary">{cls.name}</h3>
                  <p className="text-sm text-muted-foreground">Section: {cls.section}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => navigate(`/classes/edit/${cls.id}`)} className="p-2 hover:bg-muted rounded">
                    <Edit size={16} className="text-muted-foreground" />
                  </button>
                  <button onClick={() => handleDelete(cls.id)} className="p-2 hover:bg-muted rounded opacity-50 cursor-not-allowed">
                    <Trash2 size={16} className="text-muted-foreground" />
                  </button>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2">
                  <Users size={16} className="text-muted-foreground" />
                  <span className="text-sm">Capacity: {cls.capacity}</span>
                </div>
                <div className="text-sm text-muted-foreground">Teacher: {cls.teacherName || 'Not assigned'}</div>
              </div>

              <Button variant="outline" size="sm" className="w-full" onClick={() => navigate(`/classes/sections?classId=${cls.id}`)}>
                View Sections
              </Button>
            </div>
          ))
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div className="stat-card">
          <p className="stat-label">Total Classes</p>
          <p className="stat-value">{classes.length}</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Total Capacity</p>
          <p className="stat-value">{classes.reduce((sum, c) => sum + (c.capacity || 0), 0)}</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Avg Class Size</p>
          <p className="stat-value">{classes.length > 0 ? Math.round(classes.reduce((sum, c) => sum + (c.capacity || 0), 0) / classes.length) : 0}</p>
        </div>
      </div>
    </div>
  );
};

export default ClassManagement;
