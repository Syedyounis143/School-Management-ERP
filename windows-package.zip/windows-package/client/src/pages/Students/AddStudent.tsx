import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';
import { ArrowLeft } from 'lucide-react';

const AddStudent = () => {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    rollNumber: '',
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    gender: '' as 'male' | 'female' | 'other' | '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    fatherName: '',
    fatherPhone: '',
    motherName: '',
    motherPhone: '',
    emergencyContact: '',
    emergencyPhone: '',
    enrollmentDate: new Date().toISOString().split('T')[0],
  });

  const createMutation = trpc.students.create.useMutation();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === 'gender') {
      setFormData(prev => ({ ...prev, [name]: value as 'male' | 'female' | 'other' | '' }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const submitData = {
        ...formData,
        gender: (formData.gender as 'male' | 'female' | 'other' | undefined) || undefined,
      };
      await createMutation.mutateAsync(submitData);
      toast.success('Student added successfully');
      navigate('/students');
    } catch (error) {
      toast.error('Failed to add student');
    }
  };

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center gap-4">
        <button onClick={() => navigate('/students')} className="p-2 hover:bg-muted rounded-lg">
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-4xl font-bold gradient-text">Add Student</h1>
          <p className="text-muted mt-2">Enter student information</p>
        </div>
      </div>

      <div className="card-elegant p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Basic Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <Label>Roll Number *</Label>
                <Input name="rollNumber" value={formData.rollNumber} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <Label>First Name *</Label>
                <Input name="firstName" value={formData.firstName} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <Label>Last Name *</Label>
                <Input name="lastName" value={formData.lastName} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <Label>Date of Birth</Label>
                <Input type="date" name="dateOfBirth" value={formData.dateOfBirth} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>Gender</Label>
                <select name="gender" value={formData.gender} onChange={handleChange} className="input-elegant">
                  <option value="">Select Gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div className="form-group">
                <Label>Enrollment Date *</Label>
                <Input type="date" name="enrollmentDate" value={formData.enrollmentDate} onChange={handleChange} required />
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <Label>Email</Label>
                <Input type="email" name="email" value={formData.email} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>Phone</Label>
                <Input name="phone" value={formData.phone} onChange={handleChange} />
              </div>
              <div className="form-group md:col-span-2">
                <Label>Address</Label>
                <Textarea name="address" value={formData.address} onChange={handleChange} rows={3} />
              </div>
              <div className="form-group">
                <Label>City</Label>
                <Input name="city" value={formData.city} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>State</Label>
                <Input name="state" value={formData.state} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>Zip Code</Label>
                <Input name="zipCode" value={formData.zipCode} onChange={handleChange} />
              </div>
            </div>
          </div>

          {/* Parent Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Parent Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <Label>Father's Name</Label>
                <Input name="fatherName" value={formData.fatherName} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>Father's Phone</Label>
                <Input name="fatherPhone" value={formData.fatherPhone} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>Mother's Name</Label>
                <Input name="motherName" value={formData.motherName} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>Mother's Phone</Label>
                <Input name="motherPhone" value={formData.motherPhone} onChange={handleChange} />
              </div>
            </div>
          </div>

          {/* Emergency Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Emergency Contact</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <Label>Emergency Contact Name</Label>
                <Input name="emergencyContact" value={formData.emergencyContact} onChange={handleChange} />
              </div>
              <div className="form-group">
                <Label>Emergency Contact Phone</Label>
                <Input name="emergencyPhone" value={formData.emergencyPhone} onChange={handleChange} />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex gap-4 pt-6 border-t border-border">
            <Button type="submit" disabled={createMutation.isPending}>
              {createMutation.isPending ? 'Adding...' : 'Add Student'}
            </Button>
            <Button type="button" variant="outline" onClick={() => navigate('/students')}>
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddStudent;
