import React, { useState } from 'react';
import { Search, Plus, Eye, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

const StudentList = () => {
  const [search, setSearch] = useState('');
  const [, navigate] = useLocation();
  const { data: students = [], isLoading } = trpc.students.list.useQuery({ search: search || undefined });

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">Students</h1>
          <p className="text-muted mt-2">Manage student information and records</p>
        </div>
        <Button onClick={() => navigate('/students/add')} className="gap-2">
          <Plus size={20} />
          Add Student
        </Button>
      </div>

      {/* Search Bar */}
      <div className="card-elegant p-4">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
            <Input
              placeholder="Search by name, roll number..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </div>

      {/* Students Table */}
      <div className="card-elegant overflow-hidden">
        <table className="table-elegant">
          <thead>
            <tr>
              <th>Roll Number</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={6} className="text-center py-8 text-muted">
                  Loading students...
                </td>
              </tr>
            ) : students.length === 0 ? (
              <tr>
                <td colSpan={6} className="text-center py-8 text-muted">
                  No students found
                </td>
              </tr>
            ) : (
              students.map((student) => (
                <tr key={student.id}>
                  <td className="font-medium">{student.rollNumber}</td>
                  <td>{`${student.firstName} ${student.lastName}`}</td>
                  <td className="text-muted">{student.email || '-'}</td>
                  <td>{student.phone || '-'}</td>
                  <td>
                    <span className={`status-${student.status}`}>
                      {student.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-2">
                      <button className="p-1 hover:bg-muted rounded transition-colors">
                        <Eye size={16} className="text-muted-foreground" />
                      </button>
                      <button className="p-1 hover:bg-muted rounded transition-colors">
                        <Edit size={16} className="text-muted-foreground" />
                      </button>
                      <button className="p-1 hover:bg-muted rounded transition-colors">
                        <Trash2 size={16} className="text-destructive" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination info */}
      <div className="text-sm text-muted-foreground">
        Showing {students.length} student{students.length !== 1 ? 's' : ''}
      </div>
    </div>
  );
};

export default StudentList;
