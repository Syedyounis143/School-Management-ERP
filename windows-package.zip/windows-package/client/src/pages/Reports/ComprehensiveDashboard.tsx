import React, { useState } from 'react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Download, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

const ComprehensiveDashboard = () => {
  const [reportType, setReportType] = useState('performance');
  const [selectedClass, setSelectedClass] = useState('all');

  const performanceData = [
    { class: '10-A', avg: 82, pass: 95, fail: 5 },
    { class: '10-B', avg: 78, pass: 90, fail: 10 },
    { class: '9-A', avg: 80, pass: 92, fail: 8 },
    { class: '9-B', avg: 76, pass: 88, fail: 12 },
  ];

  const attendanceData = [
    { month: 'Jan', present: 85, absent: 15 },
    { month: 'Feb', present: 88, absent: 12 },
    { month: 'Mar', present: 82, absent: 18 },
    { month: 'Apr', present: 90, absent: 10 },
  ];

  const financialData = [
    { category: 'Collected', value: 450000, fill: '#10b981' },
    { category: 'Pending', value: 120000, fill: '#f59e0b' },
    { category: 'Overdue', value: 30000, fill: '#ef4444' },
  ];

  const gradeDistribution = [
    { grade: 'A', students: 45 },
    { grade: 'B', students: 62 },
    { grade: 'C', students: 38 },
    { grade: 'D', students: 12 },
    { grade: 'F', students: 3 },
  ];

  const handleExportReport = () => {
    toast.success('Report exported as PDF');
  };

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">Reports & Analytics</h1>
          <p className="text-muted mt-2">Comprehensive school performance analytics</p>
        </div>
        <Button onClick={handleExportReport} className="gap-2">
          <Download size={20} />
          Export Report
        </Button>
      </div>

      <div className="card-elegant p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="form-group">
            <Label>Report Type</Label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
              className="input-elegant mt-2"
            >
              <option value="performance">Student Performance</option>
              <option value="attendance">Attendance Summary</option>
              <option value="financial">Financial Report</option>
              <option value="grades">Grade Distribution</option>
            </select>
          </div>

          <div className="form-group">
            <Label>Filter by Class</Label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="input-elegant mt-2"
            >
              <option value="all">All Classes</option>
              <option value="10-A">Class 10-A</option>
              <option value="10-B">Class 10-B</option>
              <option value="9-A">Class 9-A</option>
              <option value="9-B">Class 9-B</option>
            </select>
          </div>

          <div className="flex items-end">
            <Button variant="outline" className="w-full gap-2">
              <Filter size={20} />
              Advanced Filters
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="stat-card">
          <p className="stat-label">Total Students</p>
          <p className="stat-value">160</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Avg Attendance</p>
          <p className="stat-value">86%</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Pass Rate</p>
          <p className="stat-value">91%</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Fee Collection</p>
          <p className="stat-value">79%</p>
        </div>
      </div>

      {reportType === 'performance' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card-elegant p-6">
            <h3 className="text-lg font-semibold mb-4">Class-wise Average Performance</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="class" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="avg" fill="#3b82f6" name="Average Score" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="card-elegant p-6">
            <h3 className="text-lg font-semibold mb-4">Pass/Fail Statistics</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="class" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="pass" fill="#10b981" name="Pass %" />
                <Bar dataKey="fail" fill="#ef4444" name="Fail %" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {reportType === 'attendance' && (
        <div className="card-elegant p-6">
          <h3 className="text-lg font-semibold mb-4">Monthly Attendance Trend</h3>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={attendanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="present" stroke="#10b981" name="Present %" strokeWidth={2} />
              <Line type="monotone" dataKey="absent" stroke="#ef4444" name="Absent %" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {reportType === 'financial' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card-elegant p-6">
            <h3 className="text-lg font-semibold mb-4">Fee Collection Status</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={financialData} cx="50%" cy="50%" labelLine={false} label={({ category, value }: any) => `${category}: ₹${((value as number) / 100000).toFixed(1)}L`} outerRadius={80} fill="#8884d8" dataKey="value">
                  {financialData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: any) => `₹${((value as number) / 100000).toFixed(1)}L`} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="card-elegant p-6">
            <h3 className="text-lg font-semibold mb-4">Financial Summary</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-lg">
                <span className="font-medium">Total Collected</span>
                <span className="text-emerald-600 font-bold">₹4.5L</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                <span className="font-medium">Pending Payment</span>
                <span className="text-amber-600 font-bold">₹1.2L</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                <span className="font-medium">Overdue Payment</span>
                <span className="text-red-600 font-bold">₹30K</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <span className="font-medium">Collection Rate</span>
                <span className="text-blue-600 font-bold">79%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {reportType === 'grades' && (
        <div className="card-elegant p-6">
          <h3 className="text-lg font-semibold mb-4">Grade Distribution</h3>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={gradeDistribution}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="grade" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="students" fill="#3b82f6" name="Number of Students" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
};

export default ComprehensiveDashboard;
