import React, { useState } from 'react';
import { Plus, Search, BookOpen, RotateCw, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { useLocation } from 'wouter';

const LibraryManagement = () => {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [, navigate] = useLocation();

  const books = [
    { id: 1, title: 'Mathematics Part-I', author: 'NCERT', isbn: '978-81-7525-123-4', class: '10', available: 15, total: 20, status: 'available' },
    { id: 2, title: 'Science Textbook', author: 'NCERT', isbn: '978-81-7525-124-1', class: '10', available: 0, total: 20, status: 'unavailable' },
    { id: 3, title: 'English Literature', author: 'CBSE', isbn: '978-81-7525-125-8', class: '10', available: 8, total: 15, status: 'available' },
    { id: 4, title: 'Social Studies', author: 'NCERT', isbn: '978-81-7525-126-5', class: '10', available: 3, total: 10, status: 'low' },
  ];

  const transactions = [
    { id: 1, student: 'Aarav Kumar', book: 'Mathematics Part-I', issueDate: '2024-03-01', dueDate: '2024-03-15', status: 'active', fine: 0 },
    { id: 2, student: 'Priya Sharma', book: 'English Literature', issueDate: '2024-02-20', dueDate: '2024-03-05', status: 'overdue', fine: 50 },
    { id: 3, student: 'Rohan Patel', book: 'Science Textbook', issueDate: '2024-02-15', dueDate: '2024-03-01', status: 'returned', fine: 0 },
  ];

  const filteredBooks = books.filter(b => 
    b.title.toLowerCase().includes(search.toLowerCase())
  );

  const handleIssueBook = () => {
    toast.success('Book issued successfully');
  };

  const handleReturnBook = (transactionId: number) => {
    toast.success('Book returned successfully');
  };

  const totalBooks = books.reduce((sum, b) => sum + b.total, 0);
  const availableBooks = books.reduce((sum, b) => sum + b.available, 0);
  const issuedBooks = totalBooks - availableBooks;

  return (
    <div className="space-elegant">
      <div className="section-header flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold gradient-text">Library Management</h1>
          <p className="text-muted mt-2">Manage books, issues, and returns</p>
        </div>
        <Button onClick={handleIssueBook} className="gap-2">
          <Plus size={20} />
          Issue Book
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="stat-card">
          <p className="stat-label">Total Books</p>
          <p className="stat-value">{totalBooks}</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Available</p>
          <p className="stat-value text-emerald-600">{availableBooks}</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Issued</p>
          <p className="stat-value text-amber-600">{issuedBooks}</p>
        </div>
        <div className="stat-card">
          <p className="stat-label">Overdue</p>
          <p className="stat-value text-destructive">2</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Book Catalog */}
        <div className="card-elegant p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Book Catalog</h3>
            <BookOpen size={24} className="text-primary" />
          </div>

          <div className="relative mb-4">
            <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
            <Input
              placeholder="Search books..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            {filteredBooks.map((book) => (
              <div key={book.id} className="p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium text-sm">{book.title}</p>
                    <p className="text-xs text-muted-foreground">{book.author}</p>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    book.status === 'available' ? 'bg-emerald-100 text-emerald-700' :
                    book.status === 'low' ? 'bg-amber-100 text-amber-700' :
                    'bg-destructive/10 text-destructive'
                  }`}>
                    {book.available}/{book.total}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">ISBN: {book.isbn}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="card-elegant p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Recent Transactions</h3>
            <RotateCw size={24} className="text-primary" />
          </div>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            {transactions.map((trans) => (
              <div key={trans.id} className="p-3 border border-border rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium text-sm">{trans.student}</p>
                    <p className="text-xs text-muted-foreground">{trans.book}</p>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    trans.status === 'active' ? 'bg-blue-100 text-blue-700' :
                    trans.status === 'overdue' ? 'bg-destructive/10 text-destructive' :
                    'bg-emerald-100 text-emerald-700'
                  }`}>
                    {trans.status.charAt(0).toUpperCase() + trans.status.slice(1)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Due: {trans.dueDate}</span>
                  {trans.status === 'active' && (
                    <button onClick={() => handleReturnBook(trans.id)} className="text-primary hover:underline">
                      Return
                    </button>
                  )}
                  {trans.fine > 0 && (
                    <span className="text-destructive font-medium">Fine: ₹{trans.fine}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LibraryManagement;
