@echo off
setlocal enabledelayedexpansion

echo.
echo ========================================
echo School Management System - Server
echo ========================================
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo Node.js is not installed!
    echo.
    echo Please download and install Node.js from:
    echo https://nodejs.org/
    echo.
    echo After installing Node.js, run this file again.
    pause
    exit /b 1
)

echo Node.js found.
echo.

REM Check if node_modules exists
if not exist "node_modules" (
    echo Installing dependencies (first time only)...
    echo.
    call npm install --legacy-peer-deps
    if %errorlevel% neq 0 (
        echo Error: Failed to install dependencies
        pause
        exit /b 1
    )
    echo.
)

echo ========================================
echo Starting application...
echo ========================================
echo.
echo The application will be available at:
echo http://localhost:3000
echo.
echo Opening browser in 5 seconds...
echo.

timeout /t 5

REM Open browser
start http://localhost:3000

REM Start the server directly
echo Starting server...
node dist/index.js

pause
